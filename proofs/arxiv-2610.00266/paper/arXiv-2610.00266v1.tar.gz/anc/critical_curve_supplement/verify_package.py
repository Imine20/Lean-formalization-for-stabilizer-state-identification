#!/usr/bin/env python3
"""Verify all files against the saved package checksums."""
from pathlib import Path
import hashlib
import json

ROOT = Path(__file__).resolve().parent
records = json.loads((ROOT / 'package_checksums.json').read_text())
for record in records:
    path = ROOT / record['path']
    if not path.is_file():
        raise SystemExit(f'Missing file: {record["path"]}')
    actual = hashlib.sha256(path.read_bytes()).hexdigest()
    if actual != record['sha256']:
        raise SystemExit(f'Checksum mismatch: {record["path"]}')
print(f'Package integrity verified: {len(records)} files.')
