#!/usr/bin/env python3
"""Compare logarithms of probabilities and absolute finite-size corrections.

The curves here are deterministic formula evaluations, not Monte Carlo data.
Do not subtract the 70-digit independent-frame export: several n=256
differences are below its serialization precision.
"""
from pathlib import Path
from decimal import Decimal, localcontext
import csv
import json
import math
import textwrap
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
import reference_evaluator as ref

ROOT=Path(__file__).resolve().parent
NS=[4,8,12,16,24,32,64,128,256]
COLORS=['#185B83','#185B83','#B26324','#B26324','#75648C','#75648C','#657434','#657434','#202020']
MARKERS=['o','s','^','v','D','P','<','>','x']


def data():
    source=list(csv.DictReader((ROOT/'data/source_theory_curves.csv').open()))
    records=[]
    for row in source:
        n,c=int(row['n']),int(row['offset_c'])
        finite=Decimal(row['finite_formula']);limit=Decimal(row['fixed_offset_series'])
        precision=90
        if n==256:
            precision=160
            finite=ref.finite_success(n,n+c,precision=precision)
            limit=ref.limiting_success(c,precision=precision,r_max=130)
        with localcontext() as ctx:
            ctx.prec=200
            difference=finite-limit
            assert difference!=0
            records.append({'n':n,'offset_c':c,'finite_probability':str(finite),
                            'fixed_offset_series':str(limit),'signed_difference':str(difference),
                            'absolute_difference':str(abs(difference)),
                            'relative_absolute_difference':str(abs(difference)/limit),
                            'formula_precision_digits':precision})
    with (ROOT/'data/log_comparison.csv').open('w',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=list(records[0]));writer.writeheader();writer.writerows(records)
    checks=[]
    for c in [-2,2,6]:
        first=next(r for r in records if r['n']==256 and r['offset_c']==c)
        with localcontext() as ctx:
            ctx.prec=220
            again=ref.finite_success(256,256+c,precision=200)-ref.limiting_success(c,precision=200,r_max=150)
            relative=abs(again-Decimal(first['signed_difference']))/abs(again)
        assert relative<Decimal('1e-60')
        checks.append({'n':256,'c':c,'first_precision':160,'second_precision':200,
                       'relative_change_of_difference':str(relative)})
    (ROOT/'data/precision_checks.json').write_text(json.dumps(checks,indent=2)+'\n')
    return records


def main():
    path=ROOT/'data/log_comparison.csv'
    if path.exists():
        records=list(csv.DictReader(path.open()))
        for r in records:r['n'],r['offset_c']=int(r['n']),int(r['offset_c'])
    else:records=data()
    plt.rcParams.update({'font.family':'serif','font.serif':['Times New Roman','DejaVu Serif'],
                         'mathtext.fontset':'stix','font.size':9,'axes.labelsize':10,'axes.titlesize':10,
                         'xtick.labelsize':9,'ytick.labelsize':9,'legend.fontsize':9,
                         'axes.linewidth':.65,'pdf.fonttype':42,'ps.fonttype':42,'svg.fonttype':'path'})
    fig,(a,b)=plt.subplots(1,2,figsize=(7.16,4.55))
    handles=[]
    for i,n in enumerate(NS):
        rows=sorted([r for r in records if r['n']==n],key=lambda r:r['offset_c'])
        c=[r['offset_c'] for r in rows]
        p=[float(Decimal(r['finite_probability'])) for r in rows]
        d=[float(Decimal(r['absolute_difference'])) for r in rows]
        style='-' if i%2==0 else (0,(3,1.5))
        a.semilogy(c,p,color=COLORS[i],ls=style,lw=.85,marker=MARKERS[i],ms=3.0,
                   mfc='white',mew=.65,zorder=1+i/10)
        b.semilogy(c,d,color=COLORS[i],ls=style,lw=.95,marker=MARKERS[i],ms=3.6,
                   mfc='white',mew=.7)
        handles.append(Line2D([],[],color=COLORS[i],ls=style,lw=1,marker=MARKERS[i],
                              markersize=4,markerfacecolor='white',label=fr'$n={n}$'))
    first=sorted([r for r in records if r['n']==4],key=lambda r:r['offset_c'])
    a.semilogy([r['offset_c'] for r in first],[float(r['fixed_offset_series']) for r in first],
               color='black',lw=1.3,ls=(0,(5,2)),zorder=5)
    a.text(.96,.45,'Black dashed: fixed-offset series',transform=a.transAxes,ha='right',va='top',fontsize=9)
    a.set_title('(a) Log scale on probability',loc='left',pad=8)
    b.set_title('(b) Log scale on finite-size deviation',loc='left',pad=8)
    a.set_ylabel('Success probability');a.set_ylim(1e-4,1.4)
    b.set_ylabel(r'$|P^*_{n,n+c}-P_{\infty}(c)|$')
    b.set_yticks([1,1e-20,1e-40,1e-60,1e-80])
    for ax in [a,b]:
        ax.set_xlabel(r'Offset $c=k-n$');ax.set_xlim(-3.35,7.35)
        ax.set_xticks(list(range(-3,8)));ax.grid(axis='y',color='.88',ls=':',lw=.5)
        ax.tick_params(direction='in',top=True,right=True,pad=3)
    fig.subplots_adjust(left=.085,right=.985,bottom=.33,top=.905,wspace=.30)
    fig.legend(handles=handles,loc='lower center',bbox_to_anchor=(.535,.115),ncol=5,
               frameon=False,handlelength=1.75,columnspacing=1.2,labelspacing=.5)
    note=('Deterministic formula comparison, not sampling residuals. Differences are subtracted before conversion '
          'to plotting precision; n=256 uses 160-digit evaluations. Absolute values omit the sign. '
          'P-infinity denotes the proposed fixed-offset series; lines guide the eye.')
    fig.text(.085,.089,'\n'.join(textwrap.wrap(note,112)),ha='left',va='top',fontsize=9,linespacing=1.2)
    fig.canvas.draw();renderer=fig.canvas.get_renderer();bounds=fig.bbox
    for t in fig.findobj(matplotlib.text.Text):
        if t.get_visible() and t.get_text():
            box=t.get_window_extent(renderer)
            if box.width and box.height:
                # Ignore logarithmic locator labels outside the view limits.
                if t in [tick.label1 for ax in [a,b] for tick in ax.yaxis.get_major_ticks()+ax.yaxis.get_minor_ticks()]:continue
                assert box.x0>=-.5 and box.y0>=-.5 and box.x1<=bounds.width+.5 and box.y1<=bounds.height+.5,t.get_text()
    fig.savefig(ROOT/'TIT_log_scale_comparison.pdf')
    fig.savefig(ROOT/'TIT_log_scale_comparison.png',dpi=450)
    plt.close(fig)
    print(ROOT/'TIT_log_scale_comparison.pdf')


if __name__=='__main__':main()
