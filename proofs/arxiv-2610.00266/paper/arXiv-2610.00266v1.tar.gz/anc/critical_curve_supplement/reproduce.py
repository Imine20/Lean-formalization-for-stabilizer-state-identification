#!/usr/bin/env python3
"""Redraw both figures in a new directory without altering packaged originals."""
from pathlib import Path
import argparse
import os
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
FIGURES = [
    ('TIT_nine_panel_unit_offset', 'plot_unit_offset.py', 'TIT_unit_offset_with_deviations'),
    ('TIT_log_scale_comparison', 'compare_scales.py', 'TIT_log_scale_comparison'),
]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output-dir', type=Path, default=ROOT / 'regenerated',
                        help='New directory for working copies and redrawn figures.')
    parser.add_argument('--resample', action='store_true',
                        help='Regenerate the same seeded trials using saved independent probabilities.')
    parser.add_argument('--recompute-log', action='store_true',
                        help='Recompute high-precision differences and precision checks.')
    args = parser.parse_args()
    out = args.output_dir.resolve()
    if out.exists():
        parser.error(f'Output directory already exists: {out}. Choose a new directory.')
    out.mkdir(parents=True)
    shutil.copytree(ROOT / 'source', out / 'source')
    (out / 'figures').mkdir()
    (out / 'previews').mkdir()
    env = os.environ.copy()
    for name in ['OPENBLAS_NUM_THREADS', 'OMP_NUM_THREADS']:
        env.setdefault(name, '2')
    env['PYTHONDONTWRITEBYTECODE'] = '1'

    def run(folder, script):
        subprocess.run([sys.executable, str(folder / script)], cwd=folder,
                       env=env, check=True)

    for directory, script, stem in FIGURES:
        folder = out / 'source' / directory
        if directory == 'TIT_nine_panel_unit_offset' and args.resample:
            run(folder, 'prepare_samples.py')
        if directory == 'TIT_log_scale_comparison' and args.recompute_log:
            (folder / 'data/log_comparison.csv').unlink()
        run(folder, script)
        if directory == 'TIT_nine_panel_unit_offset':
            run(folder, 'verify_results.py')
        shutil.copy2(folder / f'{stem}.pdf', out / 'figures' / f'{stem}.pdf')
        shutil.copy2(folder / f'{stem}.png', out / 'previews' / f'{stem}.png')
    print(f'Both redrawn PDFs: {out / "figures"}')


if __name__ == '__main__':
    main()
