# arXiv distribution of release 1.0.0

Distribution identifier: 1.0.0-arxiv.1. The files are provided under
`anc/critical_curve_supplement/` in `arxiv_submission.zip`.
The guide is supplied as PDF and its TeX source is omitted from ancillary
files. Program and numerical input bytes are unchanged from release 1.0.0.
The README, guide, citation metadata and checksums identify this layout.
The following notes describe numerical release 1.0.0.

# Release 1.0.0 — 2026-09-24

This fixed computational supplement accompanies *Exact Critical Curve for
Uniform Stabilizer-State Identification*. The archive is prepared for
submission with the manuscript. No public repository or DOI has been created.
Start with REPRODUCIBILITY_GUIDE.pdf or README_EN.md.

## Checksum discrepancy and documented changes

Both incoming checksum manifests disagreed only on
`source/TIT_log_scale_comparison/compare_scales.py` (42/43 and 51/52 other
entries matched). They expected 6,403 bytes and SHA-256
`253bc1d95b6566094caf63a0760fc712e1de455a553b08e6023d670c50bc5320`.
The incoming file had 6,385 bytes and SHA-256
`3d91a105d753e10dfd7e6c8c65c3e575359284efb6cc239ac550a611dffac0ae`.
The original source with the expected digest was not recovered. A project-wide
filename inventory found no relevant archive; unrelated named archives were
not expanded. The old PDF omits the star in the finite probability label
present in the incoming source. This identifies a label change but does not
establish the full source difference or its cause. The discrepancy is not
described as proven cosmetic-only.

`provenance/pre_release/` preserves both old manifests, the incoming source,
the old logarithmic PDF, the old START_HERE.md, and the forensic findings.
The new release intentionally changes two plot annotations to say
"fixed-offset limit"; that exact edit is recorded in
`provenance/release_plot_annotations.patch`. Numerical code expressions were
not changed in this edit. The logarithmic PDF and preview were regenerated;
the manuscript uses the same regenerated PDF. Original numerical data and
high-precision records remain unchanged. The nine-panel PDF remains the
original plot; its regeneration was checked separately.

The root `package_checksums.json` and `delivery_checksums.json` are refreshed
for their original 43/52-path scopes. `release_manifest.json` covers the full
current payload, including the new guide, metadata, validation records,
verifier, and preserved provenance. Its only omissions are itself and the
explicit generated-output/cache exclusions. Historical manifests under
`provenance/pre_release/` are evidence, not current integrity checks.

## Validation actually performed for this release

- Ran `reproduce.py --resample --recompute-log` in a fresh working directory.
  All 99 log-comparison records and all three precision checks match the
  saved files byte-for-byte. All 99 arrays / 99,000 fixed-seed binary outcomes
  and the NPZ file also match byte-for-byte. The 99-row theoretical curves
  match byte-for-byte.
- Counts, probabilities, deterministic differences, and sampling residual
  centers remain exact. Recomputed confidence endpoints differ at most
  4.5e-16 from their saved decimal representations; translated endpoints
  differ at most 4.5e-14 percentage points. One panel RMSE differs by 5e-19.
  These differences are explicitly recorded as floating-point rounding,
  not exact equality.
- Recomputed the 11 independent frame points at n=4, c=-3,...,7, at 100 digits.
  All serialized success probabilities match the saved records exactly.
- Exercised the release verifier on 23 small fixtures, including altered,
  missing, unexpected, duplicate, unsafe, and excluded paths.

Detailed results: `validation/release_regression.json`,
`validation/release_frame_n4.json`, and `validation/release_verifier_tests.json`.
The actual validation environment is `validation/release_environment.json`.
The pinned historical environment was not reinstalled; its metadata remains
in `environment.json`. In particular, the new checks used Python 3.11.15,
NumPy 2.4.6, SciPy 1.17.1, Matplotlib 3.10.9, and mpmath 1.3.0.
The high-n independent-frame diagonalizations were not rerun for this release.
Earlier validation reports and source comments retain their historical scope.

## Reproduction scope

`recompute_frame.py` builds and diagonalizes frame matrices.
`reproduce.py --resample` samples the saved frame probabilities and does not
automatically consume newly recomputed JSON. `--recompute-log` reuses saved
90-digit n<256 values, reevaluates n=256 at 160 digits, and checks three cases
at 200 digits. Use the guide's distinct new output directories.

The complete code-pair-count mathematical appendix is outside this packaging
revision. No numerical theorem or probability formula was changed.
