# 正文整合用图包

本文件夹汇集最后两张图、生成程序、原始采样、理论数据及验证记录。
两张最终 PDF 均直接复制，内容与交付版本逐字节一致。原研究目录和原图未改动。

## 直接用于正文的文件

| 文件 | 内容 | 页面尺寸 |
| --- | --- | --- |
| `figures/TIT_unit_offset_with_deviations.pdf` | 3×3 模拟图；九个 n；每点 1,000 次随机试验及逐点 95% 置信区间；下方显示有符号采样残差 | 7.16 × 8.35 in |
| `figures/TIT_log_scale_comparison.pdf` | 成功概率对数轴与有限尺寸绝对偏差对数轴的并排对比 | 7.16 × 4.55 in |

两图均为嵌入字体的矢量 PDF，offset 为 -3 到 7 的每个整数，
n = 4, 8, 12, 16, 24, 32, 64, 128, 256。
`previews/` 提供对应 PNG，正文排版优先使用 PDF。
PDF 保留了现有图内说明，可直接插入跨双栏图环境；若正文另写图注并希望移除图内说明，
可在工作副本中编辑对应绘图程序后重绘。

## 目录

```text
figures/                         两张最终 PDF
previews/                        两张 PNG 预览
source/TIT_nine_panel_unit_offset/  3×3 图的程序、模型、数据和验证记录
source/TIT_log_scale_comparison/    log 图的程序、高精度数据和验证记录
reproduce.py                     一键在新目录重绘
verify_package.py                校验打包文件是否完整
requirements.txt                 本次使用的 Python 库版本
environment.json                 原生成环境与字体记录
source_provenance.json            来源与原文件哈希、修改时间
package_checksums.json           包内文件 SHA-256
```

## 重绘

已在 Python 3.12.9 环境验证。进入本文件夹后运行：

```sh
python -m pip install -r requirements.txt
python verify_package.py
python reproduce.py
```

重绘结果保存到新建的 `regenerated/figures/`；打包的 PDF、程序和数据不被覆盖。
默认使用已保存的数据，不重新计算耗时的独立测量矩阵。
再次运行时可指定一个尚不存在的输出目录：

```sh
python reproduce.py --output-dir another_run
```

如需同时重新生成固定种子的 99,000 个试验，以及 log 图的高精度差值：

```sh
python reproduce.py --resample --recompute-log --output-dir recalculated_run
```

以上重新采样仍使用包内保存的独立矩阵概率。独立矩阵计算代码保存在
`source/TIT_nine_panel_unit_offset/model/independent_code_frame.py`；
`generate_unit_additional.py` 和 `generate_exceptional.py` 可重算相应新增点。
不要求安装 LaTeX。Times New Roman 不可用时，绘图程序退回 DejaVu Serif；
数据不变，但字体外观可能不同。`gmpy2` 可加速大矩阵高精度计算，不是直接重绘的必需依赖。

## 正文中应区分的两种偏差

- 3×3 图下方：`100 × (模拟成功频率 − 有限 n 理论概率)`，单位为百分点；
  误差棒为逐点 95% Clopper–Pearson 区间经平移和缩放后的结果。
- log 图右侧：`abs(有限 n 理论概率 − 固定偏移极限级数)`，为确定性高精度计算。
  绝对值不保留正负方向；有符号差值保存在 CSV 中。

1000 次试验无法识别大 n 时极小的有限尺寸修正。log 图并非对这些微小差异的
Monte Carlo 实验验证。极限参考仍沿用研究实现中的 proposed fixed-offset series 表述；
图片本身不构成其极限性质的证明。高精度计算方法详见 log 子目录的 README。

## 打包时的唯一程序改动

仅在副本中修改了 `source/TIT_nine_panel_unit_offset/verify_results.py`：
对旧机器绝对路径的历史保留检查改为可选参数 `--check-original-files`。
默认仍验证全部包内采样、置信区间、残差、RMSE、取点和旧样本保留情况。
`previous_version_manifest.json` 作为历史来源记录保留，不是默认运行的外部依赖。
其他生成程序与来源相同。包内已有 preflight 和审查文件是原交付版本的验证记录。
