#!/usr/bin/env python3
"""Verify a release manifest and report unexpected payload files (stdlib only).

The default manifest is release_manifest.json beside this script. An optional
positional path selects another manifest; its parent is the payload root.
The manifest has schema_version=1, a nonempty release_version, a files list
of {path, sha256, bytes} records, and optional exclusions. Supported exclusion
lists are directories (relative subtrees), directory_names (at any depth),
files (exact relative paths), and file_globs (basename patterns at any depth).
The manifest is exempt from self-hashing; the verifier is not exempt.

Exit status: 0 passes, 1 payload mismatch, 2 invalid manifest or invocation.
Checksums establish consistency, not authenticity or numerical correctness.
"""
from __future__ import annotations

import argparse
import fnmatch
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import stat
import sys


class ManifestError(ValueError):
    """A manifest is malformed or cannot safely describe a payload."""


def _object_without_duplicate_keys(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ManifestError(f"Duplicate JSON object key: {key!r}")
        result[key] = value
    return result


def _safe_relative(value, context):
    if not isinstance(value, str) or not value:
        raise ManifestError(f"{context} must be a nonempty string")
    if any(ord(char) < 32 or ord(char) == 127 for char in value):
        raise ManifestError(f"Control character in {context}: {value!r}")
    if "\\" in value or ":" in value:
        raise ManifestError(f"Use portable relative POSIX paths in {context}: {value!r}")
    path = PurePosixPath(value)
    if path.is_absolute() or any(part in ("", ".", "..") for part in value.split("/")):
        raise ManifestError(f"Unsafe or noncanonical {context}: {value!r}")
    if path.as_posix() != value:
        raise ManifestError(f"Noncanonical {context}: {value!r}")
    return value


def _exclusions(value):
    if not isinstance(value, dict):
        raise ManifestError("exclusions must be a JSON object")
    allowed = {"directories", "directory_names", "files", "file_globs"}
    unknown = set(value) - allowed
    if unknown:
        raise ManifestError("Unknown exclusion fields: " + ", ".join(sorted(unknown)))
    result = {key: [] for key in allowed}
    for key, entries in value.items():
        if not isinstance(entries, list):
            raise ManifestError(f"exclusions.{key} must be a list")
        for entry in entries:
            if key == "file_globs":
                if (not isinstance(entry, str) or not entry or "/" in entry
                        or "\\" in entry or ":" in entry
                        or any(ord(c) < 32 or ord(c) == 127 for c in entry)):
                    raise ManifestError(f"Invalid basename glob: {entry!r}")
            else:
                _safe_relative(entry, f"exclusions.{key}")
                if key == "directory_names" and "/" in entry:
                    raise ManifestError(f"directory_names requires single components: {entry!r}")
            if entry in result[key]:
                raise ManifestError(f"Duplicate exclusions.{key} entry: {entry!r}")
            result[key].append(entry)
    return result


def _is_excluded(relative, exclusions, is_directory=False):
    parts = PurePosixPath(relative).parts
    if any((is_directory and relative == directory) or relative.startswith(directory + "/")
           for directory in exclusions["directories"]):
        return True
    directory_parts = parts if is_directory else parts[:-1]
    if any(part in exclusions["directory_names"] for part in directory_parts):
        return True
    if not is_directory:
        if relative in exclusions["files"]:
            return True
        if any(fnmatch.fnmatchcase(parts[-1], pattern) for pattern in exclusions["file_globs"]):
            return True
    return False


def load_manifest(path):
    path = Path(path)
    if path.is_symlink():
        raise ManifestError("The manifest itself must not be a symbolic link")
    path = path.resolve()
    try:
        payload = json.loads(path.read_text(encoding="utf-8"),
                             object_pairs_hook=_object_without_duplicate_keys)
    except (OSError, UnicodeError, json.JSONDecodeError) as error:
        raise ManifestError(f"Cannot read manifest: {error}") from error
    if not isinstance(payload, dict):
        raise ManifestError("The manifest must be a JSON object")
    if type(payload.get("schema_version")) is not int or payload["schema_version"] != 1:
        raise ManifestError("schema_version must be integer 1")
    if not isinstance(payload.get("release_version"), str) or not payload["release_version"].strip():
        raise ManifestError("release_version must be a nonempty string")
    exclusions = _exclusions(payload.get("exclusions", {}))
    records = payload.get("files")
    if not isinstance(records, list) or not records:
        raise ManifestError("files must be a nonempty list")
    indexed = {}
    for index, record in enumerate(records):
        if not isinstance(record, dict):
            raise ManifestError(f"files[{index}] must be an object")
        relative = _safe_relative(record.get("path"), f"files[{index}].path")
        if relative == path.name:
            raise ManifestError("The manifest cannot contain its own checksum")
        if relative in indexed:
            raise ManifestError(f"Duplicate payload path: {relative!r}")
        if _is_excluded(relative, exclusions):
            raise ManifestError(f"Declared payload path is also excluded: {relative!r}")
        digest = record.get("sha256")
        if not isinstance(digest, str) or re.fullmatch(r"[0-9a-f]{64}", digest) is None:
            raise ManifestError(f"Invalid lowercase SHA-256 for {relative!r}")
        if type(record.get("bytes")) is not int or record["bytes"] < 0:
            raise ManifestError(f"bytes must be a nonnegative integer for {relative!r}")
        indexed[relative] = record
    for relative in indexed:
        if any(parent.as_posix() in indexed for parent in PurePosixPath(relative).parents
               if parent.as_posix() != "."):
            raise ManifestError(f"Payload file is an ancestor of another payload path: {relative!r}")
    return path, payload, exclusions, indexed


def verify_manifest(path):
    path, payload, exclusions, records = load_manifest(path)
    root = path.parent
    errors = []
    regular_files = set()
    ignored_entries = 0

    def walk_error(error):
        errors.append(f"Cannot scan payload: {error}")

    for folder, directories, files in os.walk(root, topdown=True, followlinks=False,
                                             onerror=walk_error):
        folder = Path(folder)
        for name in sorted(directories):
            item = folder / name
            relative = item.relative_to(root).as_posix()
            if _is_excluded(relative, exclusions, is_directory=True):
                directories.remove(name)
                ignored_entries += 1
            elif item.is_symlink():
                directories.remove(name)
                errors.append(f"Symbolic-link directory is not allowed: {relative}")
        for name in sorted(files):
            item = folder / name
            relative = item.relative_to(root).as_posix()
            if relative == path.name:
                continue
            if _is_excluded(relative, exclusions):
                ignored_entries += 1
                continue
            try:
                mode = item.lstat().st_mode
            except OSError as error:
                errors.append(f"Cannot inspect {relative}: {error}")
                continue
            if stat.S_ISLNK(mode):
                errors.append(f"Symbolic-link file is not allowed: {relative}")
            elif not stat.S_ISREG(mode):
                errors.append(f"Non-regular payload entry is not allowed: {relative}")
            else:
                regular_files.add(relative)

    for relative in sorted(regular_files - records.keys()):
        errors.append(f"Unexpected file: {relative}")
    for relative in sorted(records.keys() - regular_files):
        errors.append(f"Missing regular payload file: {relative}")

    checked = 0
    matched = 0
    for relative in sorted(records.keys() & regular_files):
        item = root / relative
        record = records[relative]
        digest = hashlib.sha256()
        actual_bytes = 0
        try:
            before = item.stat()
            with item.open("rb") as handle:
                for block in iter(lambda: handle.read(1024 * 1024), b""):
                    digest.update(block)
                    actual_bytes += len(block)
            after = item.stat()
        except OSError as error:
            errors.append(f"Cannot hash {relative}: {error}")
            continue
        checked += 1
        file_errors = []
        if (before.st_ino, before.st_size, before.st_mtime_ns) != (after.st_ino, after.st_size, after.st_mtime_ns):
            file_errors.append("changed while hashing")
        if actual_bytes != record["bytes"]:
            file_errors.append(f"bytes: expected {record['bytes']}, found {actual_bytes}")
        if digest.hexdigest() != record["sha256"]:
            file_errors.append(f"SHA-256: expected {record['sha256']}, found {digest.hexdigest()}")
        if file_errors:
            errors.append(relative + ": " + "; ".join(file_errors))
        else:
            matched += 1
    return {"status": "passed" if not errors else "failed",
            "release_version": payload["release_version"],
            "manifest": str(path), "root": str(root),
            "declared_files": len(records), "checked_files": checked,
            "matched_files": matched, "ignored_entries": ignored_entries,
            "errors": errors}


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__,
                                     formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("manifest", nargs="?", type=Path,
                        default=Path(__file__).resolve().with_name("release_manifest.json"))
    parser.add_argument("--json", action="store_true", help="Print a machine-readable result")
    args = parser.parse_args(argv)
    try:
        result = verify_manifest(args.manifest)
    except (ManifestError, OSError) as error:
        result = {"status": "invalid_manifest", "errors": [str(error)]}
        status = 2
    else:
        status = 0 if result["status"] == "passed" else 1
    if args.json:
        print(json.dumps(result, indent=2))
    elif status == 2:
        print("Invalid manifest: " + result["errors"][0], file=sys.stderr)
    else:
        print(f"Release {result['release_version']}: {result['status'].upper()}; "
              f"{result['matched_files']}/{result['declared_files']} payload files match")
        print("Manifest: " + result["manifest"])
        for error in result["errors"]:
            print("  " + error, file=sys.stderr)
        if result["ignored_entries"]:
            print(f"Ignored {result['ignored_entries']} explicitly excluded entries/subtrees")
    return status


if __name__ == "__main__":
    raise SystemExit(main())
