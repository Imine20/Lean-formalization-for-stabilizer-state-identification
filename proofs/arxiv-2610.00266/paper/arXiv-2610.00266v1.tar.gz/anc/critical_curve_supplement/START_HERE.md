> **v1.0.0 release (2026-09-24):** Begin with [REPRODUCIBILITY_GUIDE.pdf](REPRODUCIBILITY_GUIDE.pdf) or [README_EN.md](README_EN.md). Verify this release with `python verify_release.py`. See [RELEASE_NOTES.md](RELEASE_NOTES.md) for validation and checksum provenance. The earlier Chinese instructions below are retained for reference.

# 独立 frame 计算与采样记录

本包对应文章 Section XII 的数值计算与两张图，包含独立 frame 计算代码、保存的高精度结果、全部原始采样、CSV 导出和复现程序。原始研究程序和记录保留不变；新增统一 frame 重算入口及便于阅读的记录导出。

## 直接查看的文件

| 文件 | 内容 |
| --- | --- |
| `source/TIT_nine_panel_unit_offset/model/independent_code_frame.py` | 独立 frame 核心：精确有理数矩阵构建、高精度对角化、PGM 成功概率 |
| `recompute_frame.py` | 新增统一入口：逐点选择精度、保存进度、支持断点续算 |
| `source/TIT_nine_panel_unit_offset/data/selected_independent_results.json` | 图中全部 99 点的完整 frame 结果，含 code classes 和数值诊断 |
| `records/frame_diagnostics.csv` | 上述 99 点的简明表格：概率、矩阵维度、精度、残差等 |
| `source/TIT_nine_panel_unit_offset/data/simulated_trials.npz` | 原始逐次 0/1 采样数组，共 99,000 条 |
| `records/trial_outcomes.csv` | 同一批原始采样的普通 CSV 导出，一行一次试验 |
| `source/TIT_nine_panel_unit_offset/data/monte_carlo_samples.csv` | 99 点的成功次数、频率、置信区间、独立概率、理论概率及偏差 |
| `source/TIT_nine_panel_unit_offset/data/sampling_summary.json` | 网格、试验数、随机种子及采样规则 |
| `source/TIT_nine_panel_unit_offset/data/panel_statistics.json` | 九个面板的 RMSE 和区间覆盖统计 |
| `source/TIT_nine_panel_unit_offset/prepare_samples.py` | 固定种子采样及统计量生成程序 |
| `source/TIT_nine_panel_unit_offset/verify_results.py` | 原始试验、种子、置信区间、残差及 RMSE 的核对程序 |
| `figures/` | 与双栏 LaTeX 包逐字节一致的两张 PDF 图 |
| `validation/` | 本次交付的核对结果 |

`records/trial_outcomes.csv` 的列为 `n,copies_k,offset_c,trial_index,success`。其中 `k=n+c`，`trial_index` 从 1 到 1000，`success=1` 表示识别成功，`0` 表示失败。NPZ 中相应数组的键为 `n{n}_k{k}`；数组顺序与 CSV 的 trial_index 一致。

## 采样范围与含义

- `n = 4,8,12,16,24,32,64,128,256`。
- 每个 n 取所有整数 `c = -3,-2,…,7`，共 99 个参数点。
- 每点 1,000 次 Bernoulli 试验，共 99,000 次。
- 随机发生器为 NumPy PCG64，种子为 `SeedSequence([20260920,n,k])`。
- Bernoulli 参数来自保存的独立 frame 计算；目标有限谱公式仅用于随后比较。
- 记录模拟理想集体 PGM 的成功/失败边缘分布，不包含物理电路或完整测量输出标签。

原始 `previous_simulated_trials.npz` 的 54 个参数点也随包保留，原始采样程序会逐位核对这些历史样本。

## 安装依赖

原记录环境为 Python 3.12.9。建议在独立环境中运行：

```sh
python -m pip install -r requirements.txt
```

独立 frame 核心只需要 mpmath；重采样、统计和绘图使用 requirements 中的 NumPy、SciPy、Matplotlib。高 n 的矩阵重算建议另装加速库：

```sh
python -m pip install gmpy2==2.2.1
```

原始高精度运行使用 gmpy2 2.2.1。未安装时 mpmath 仍可运行，但高 n 计算可能明显变慢。

## 从 frame 矩阵重新计算

先计算一个小点：

```sh
python recompute_frame.py --n 4 --offsets 0 --output regenerated/frame_example.json
```

重新计算图中的全部 99 点：

```sh
python recompute_frame.py
```

默认输出 `regenerated/independent_frame_results.json`，逐点保存。中断后继续：

```sh
python recompute_frame.py --resume
```

此入口直接调用独立 frame 模型，不读取缓存成功概率，也不导入有限谱公式或极限曲线。它根据精确矩阵迹逐点选择至少 100 位、并在迹的十进制数量级以上保留 80 位的计算精度；可用 `--dps` 手动指定。历史记录精度为 100–2606 位，压缩矩阵维度为 1–258。不要用原模块 CLI 默认的 100 位精度直接运行全部高 n 网格。

原模块仍支持直接调用，例如：

```sh
python source/TIT_nine_panel_unit_offset/model/independent_code_frame.py --n 4 --offsets 0 --dps 100 --verify-counts --output frame_example_direct.json
```

核心算法从 affine support 与 doubly-even binary code orbit 构造 frame 的对称性限制矩阵，以整数/有理数完成计数和矩阵项构造，再用 mpmath 高精度对角化。从 seed 向量在正谱上的投影计算逆平方根期望及其平方，得到 PGM 成功概率。它不调用目标有限谱公式；使用的对称性压缩也意味着不显式构造指数维完整物理矩阵。成功概率最多保存 70 位有效数字；矩阵残差与 seed 投影误差是数值诊断，不是严格区间误差认证。

## 重现原始采样及图

从保存的独立 frame 概率，重新产生同一批固定种子试验并重绘：

```sh
python reproduce.py --resample --output-dir regenerated_sampling
```

输出写入新目录，包内原始记录不被覆盖。`regenerated_sampling/source/TIT_nine_panel_unit_offset/data/` 中包含新产生的采样和统计文件。

只用保存的数据重绘：

```sh
python reproduce.py --output-dir regenerated_figures
```

`--resample` 使用的是包内保存的 frame 概率，不会触发上述耗时的矩阵重算。两种复现方式在本包中分别提供。全网格重新计算结果含新的运行时间和精度选择，JSON 文件不要求逐字节等同于历史 frame 记录；固定种子采样则可逐位核对。

log 图的数据与程序保存在 `source/TIT_log_scale_comparison/`。该图的有限尺寸差值由高精度公式计算，和随机采样残差是不同的量。原始 README 中的 “proposed fixed-offset series” 是保留的历史表述；当前文章将此曲线与 Theorem 2 对应。

## 本次核对

原包的 43 项哈希检查通过；独立工作副本重新生成了全部 99,000 个试验，与原 NPZ 逐位一致。采样汇总 CSV、理论曲线 CSV、面板统计及汇总 JSON 也与保存记录逐字节一致。成功次数、95% Clopper–Pearson 区间和九个 RMSE 已复核。本次还对新增 frame 入口运行了小规模重算；具体范围和结果见 `validation/`，没有把它表述为重新计算了全部高 n 点。

运行 `python verify_package.py` 可核对保留的原包文件。`delivery_checksums.json` 记录整个交付包（除清单自身）的 SHA-256。
