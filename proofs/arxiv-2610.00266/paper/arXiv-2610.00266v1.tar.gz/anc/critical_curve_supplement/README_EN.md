# Computational supplement: exact critical curve

This package contains the independent reduced-frame calculation, saved
high-precision results, all 99,000 binary sampling outcomes, and the programs
and records for the two numerical figures in Section XII of the manuscript.
The grid is `n = 4, 8, 12, 16, 24, 32, 64, 128, 256` and integer
`c = -3, ..., 7`, with `k = n + c`.

## Environment and integrity

This arXiv distribution is unpacked under `anc/critical_curve_supplement/`
in `arxiv_submission.zip`. Run the commands below from that supplement directory. Use a dedicated Python 3.12 environment with the pinned dependencies
in `requirements.txt`; the recorded original environment is described in
`environment.json`. The historical runs used Python 3.12.9. The independent
frame model needs `mpmath`; sampling and plotting additionally use NumPy,
SciPy, and Matplotlib. Optional `gmpy2` accelerates high-precision arithmetic.
The plotting programs use Times New Roman when available and otherwise
fall back to DejaVu Serif, so a different font installation can change the
rendered figures without changing the numerical data.

```sh
python -m pip install -r requirements.txt
python verify_release.py
```

`verify_release.py` checks every path, byte count, and SHA-256 digest in
`release_manifest.json`, and rejects unexpected files unless the manifest
explicitly excludes them. It does not hash its own manifest. The verifier
itself is included in the manifest. Checksums establish consistency with this
release manifest; they do not certify numerical correctness or authenticate
the publisher. The package also retains the scoped `package_checksums.json`
and `delivery_checksums.json` formats; use the release manifest to verify
the complete current release. Original pre-release manifests are preserved
under `provenance/pre_release/`. See the release notes for the documented
plotting-script discrepancy and its resolution.

## Recompute the independent frame

Start with a small point:

```sh
python recompute_frame.py --n 4 --offsets 0 \
  --output regenerated/frame_example.json
```

To recompute all 99 parameter pairs:

```sh
python recompute_frame.py
```

The default output is `regenerated/independent_frame_results.json`, updated
after each point. Existing output is protected. Resume the same grid with:

```sh
python recompute_frame.py --resume
```

This entry point constructs the reduced frame from exact combinatorial counts
and rational support weights. It does not import the closed finite-spectrum
formula or read cached success probabilities. Square-root normalization and
diagonalization use arbitrary-precision arithmetic. The default working
precision is `max(100, ceil(log10(trace(B))) + 80)`, calculated from the exact
trace; `--dps` can override it, with a minimum of 30 digits. This is a precision
policy, not an interval-error certificate. High-`n` calculations can be costly;
the current recomputation entry point processes parameter pairs sequentially.

Historical records use 100–2606 decimal digits and reduced matrix dimensions
1–258. Each result records the working precision, seed-projection error, and
relative eigenvalue-equation residual. Saved success probabilities retain at
most 70 significant digits. See `records/frame_diagnostics.csv` and
`source/TIT_nine_panel_unit_offset/data/selected_independent_results.json`.

## Resample and redraw

Each reproduction command requires a new output directory and leaves the
packaged inputs unchanged.

```sh
# Use saved sampling and theoretical records to redraw both figures.
python reproduce.py --output-dir regenerated_figures

# Regenerate the fixed-seed binary trials and redraw both figures.
python reproduce.py --resample --output-dir regenerated_sampling

# Rebuild the log differences and rerun the n=256 precision checks.
python reproduce.py --recompute-log --output-dir regenerated_log
```

`--resample` uses packaged saved frame probabilities, converted to floating
point, with NumPy PCG64 and `SeedSequence([20260920, n, k])`. It regenerates
1,000 Bernoulli outcomes per point. These are success/failure marginals of
the ideal collective PGM, not physical circuits or complete output-label
samples. The program also computes pointwise, equal-tailed 95%
Clopper–Pearson intervals. These intervals are not a simultaneous confidence
band.

The resampling command does not automatically consume the new JSON produced
by `recompute_frame.py`. Its inputs are the five packaged frame-record files
selected by `source/TIT_nine_panel_unit_offset/prepare_samples.py`. Keep the
published inputs unchanged when reproducing the published experiment.
Any later replacement of those inputs should be an explicit, documented
new release.

`--recompute-log` reuses saved 90-digit finite and limiting probabilities
for `n < 256`. For `n = 256`, it reevaluates the formulas at 160 digits and
performs 200-digit stability checks at `c = -2, 2, 6`. Differences are formed
before conversion to plotting precision. This path uses theoretical formula
evaluations and does not rerun the independent frame calculation.

The two flags may be combined, using another new output directory. Generated
PDF figures appear in `<output-dir>/figures/`; working copies and regenerated
data appear in `<output-dir>/source/`.

## Records and interpretation

- `source/TIT_nine_panel_unit_offset/model/independent_code_frame.py`:
  independent frame construction.
- `source/TIT_nine_panel_unit_offset/data/simulated_trials.npz` and
  `records/trial_outcomes.csv`: the same 99,000 trial outcomes in two formats.
- `source/TIT_nine_panel_unit_offset/data/monte_carlo_samples.csv`:
  counts, frequencies, intervals, comparator probabilities, and residuals.
- `source/TIT_log_scale_comparison/data/log_comparison.csv`:
  finite probabilities, limiting probabilities, and signed deterministic
  finite-size differences.
- `source/TIT_log_scale_comparison/data/precision_checks.json`:
  the three recorded precision-stability comparisons.
- `validation/`: saved verification records; consult their stated scope
  instead of interpreting them as a fresh rerun of all high-`n` calculations.

The sampling residual is `100 * (sample frequency - finite probability)`,
in percentage points. The logarithmic figure instead displays the absolute
deterministic finite-size difference. The two quantities serve different
purposes. Historical source comments describing a “proposed” or
“derived/conjectural” limiting series document the earlier development stage;
the delivered manuscript associates that series with its fixed-offset theorem.

This release is supplied as the article's accompanying computational
supplement, `arxiv_submission.zip`. Use the
actual release citation supplied with the manuscript. No public DOI is
implied by the presence of a local copy.

## arXiv distribution

This is the arXiv distribution of numerical release 1.0.0. The code and input
data retain their release values. The guide is provided as PDF; its TeX source
is omitted from ancillary files. The current release manifest describes this
distribution. Run all commands from the directory containing this README.
