#!/usr/bin/env python3
"""Recompute frame probabilities without importing the target spectrum.

The default grid contains the manuscript's 99 (n, c) pairs.  Matrix entries
and the trace are exact rationals; only diagonalization uses mpmath.  Existing
output is protected unless --resume is supplied.  Resumption checks record
keys and recomputes any point whose saved working precision is too low.
"""
from __future__ import annotations

import argparse
from fractions import Fraction
import json
from pathlib import Path
import sys
import tempfile
import time

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "source/TIT_nine_panel_unit_offset/model"))
import independent_code_frame as frame
import mpmath as mp

DEFAULT_NS = [4, 8, 12, 16, 24, 32, 64, 128, 256]
DEFAULT_OFFSETS = list(range(-3, 8))


def adaptive_precision(entries, scales_squared):
    """Use the exact reduced-frame trace and 80 guard decimal digits."""
    trace = sum((entries[i][i] * scales_squared[i]
                 for i in range(len(entries))), Fraction(0))
    if trace <= 0:
        raise ArithmeticError("The exact frame trace must be positive")
    with mp.workdps(80):
        return max(100, int(mp.ceil(mp.log10(frame.as_mp(trace)))) + 80)


def read_checkpoint(path, wanted):
    records = json.loads(path.read_text())
    if not isinstance(records, list):
        raise ValueError("Checkpoint must be a JSON list of frame records")
    indexed = {}
    required = {"n", "copies_k", "offset_c", "dps", "success",
                "matrix_dimension", "code_classes", "numerical_rank",
                "seed_projection_error", "eigen_residual_relative"}
    for record in records:
        if not isinstance(record, dict) or not required <= record.keys():
            raise ValueError("Checkpoint contains an incomplete frame record")
        for field in ("n", "copies_k", "offset_c", "dps", "matrix_dimension"):
            if type(record[field]) is not int:
                raise ValueError(f"Checkpoint field {field} must be an integer")
        n, k, c = record["n"], record["copies_k"], record["offset_c"]
        if n < 1 or k < 1 or k != n + c or record["dps"] < 30:
            raise ValueError(f"Inconsistent checkpoint parameters at n={n}, k={k}")
        key = (n, k)
        if key not in wanted:
            raise ValueError(f"Checkpoint point {key} is outside the requested grid")
        if key in indexed:
            raise ValueError(f"Duplicate checkpoint point {key}")
        with mp.workdps(80):
            probability = mp.mpf(record["success"])
            if not mp.isfinite(probability) or not 0 <= probability <= 1:
                raise ValueError(f"Invalid checkpoint probability at {key}")
        indexed[key] = record
    return indexed


def save_checkpoint(path, indexed):
    """Replace only the designated checkpoint, after writing a complete JSON."""
    records = [indexed[key] for key in sorted(indexed)]
    with tempfile.NamedTemporaryFile(mode="w", encoding="utf-8", dir=path.parent,
                                     prefix=path.name + ".", suffix=".tmp",
                                     delete=False) as handle:
        handle.write(json.dumps(records, indent=2) + "\n")
        temporary = Path(handle.name)
    temporary.replace(path)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--n", type=int, nargs="+", default=DEFAULT_NS,
                        help="Qubit counts (default: the manuscript's nine values)")
    parser.add_argument("--offsets", type=int, nargs="+", default=DEFAULT_OFFSETS,
                        help="Integer offsets c, with copies k=n+c (default: -3 through 7)")
    parser.add_argument("--output", type=Path,
                        default=ROOT / "regenerated/independent_frame_results.json")
    parser.add_argument("--resume", action="store_true",
                        help="Resume this output; recompute records below requested precision")
    parser.add_argument("--dps", type=int,
                        help="Override trace-adaptive decimal precision (minimum 30)")
    args = parser.parse_args()
    if any(n < 1 for n in args.n):
        parser.error("Every n must be positive")
    if args.dps is not None and args.dps < 30:
        parser.error("--dps must be at least 30")
    points = [(n, n + c) for n in sorted(set(args.n))
              for c in sorted(set(args.offsets))]
    if any(k < 1 for _, k in points):
        parser.error("Every requested pair must satisfy k=n+c >= 1")
    output = args.output.expanduser().resolve()
    if output.exists() and not args.resume:
        parser.error(f"Output already exists: {output}; use --resume or a new --output")
    try:
        indexed = read_checkpoint(output, set(points)) if output.exists() else {}
    except (ValueError, TypeError, KeyError) as error:
        parser.error(str(error))
    output.parent.mkdir(parents=True, exist_ok=True)
    started = time.perf_counter()
    computed = reused = upgraded = 0
    print(f"Independent frame: {len(points)} points; mpmath {mp.__version__}; "
          f"backend={mp.libmp.BACKEND}; output={output}", flush=True)
    for index, (n, k) in enumerate(points, 1):
        point_started = time.perf_counter()
        classes, _, entries, scales_squared = frame.exact_frame_data(n, k)
        dps = args.dps if args.dps is not None else adaptive_precision(entries, scales_squared)
        existing = indexed.get((n, k))
        if existing is not None and existing["dps"] >= dps:
            if existing["matrix_dimension"] != len(classes):
                raise ValueError(f"Checkpoint matrix dimension mismatch at n={n}, k={k}")
            reused += 1
            print(f"[{index}/{len(points)}] reuse n={n}, c={k-n:+d}, k={k}; "
                  f"saved dps={existing['dps']} >= requested {dps}", flush=True)
            continue
        if existing is not None:
            upgraded += 1
            print(f"[{index}/{len(points)}] recompute n={n}, c={k-n:+d}: "
                  f"saved dps={existing['dps']} < requested {dps}", flush=True)
        print(f"[{index}/{len(points)}] calculate n={n}, c={k-n:+d}, k={k}; "
              f"dimension={len(classes)}, dps={dps}", flush=True)
        # exact_frame_data has just populated the model's cache, so this call
        # reuses the exact entries instead of constructing the matrix twice.
        record = frame.pgm_success(n, k, dps=dps)
        record["total_elapsed_seconds_including_exact_build"] = time.perf_counter() - point_started
        indexed[n, k] = record
        save_checkpoint(output, indexed)
        computed += 1
        print(f"  success={record['success'][:24]}; "
              f"seed_error={record['seed_projection_error']}; "
              f"relative_residual={record['eigen_residual_relative']}; "
              f"seconds={record['total_elapsed_seconds_including_exact_build']:.3f}", flush=True)
    print(f"Complete: computed={computed}, upgraded={upgraded}, reused={reused}, "
          f"records={len(indexed)}, elapsed_seconds={time.perf_counter()-started:.3f}", flush=True)
    print("Stored success values retain at most 70 significant digits. "
          "No target-spectrum or limiting-curve evaluator was imported.", flush=True)


if __name__ == "__main__":
    main()
