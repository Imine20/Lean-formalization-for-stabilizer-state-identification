#!/usr/bin/env python3
"""Binary fixed-offset stabilizer-identification curve.

This research implementation evaluates two objects:

1. the finite-(n,t) optimal success probability obtained from the closed
   ordinary/exceptional spectrum of the uniform stabilizer moment; and
2. the fixed-offset limit t=n+c, written as a positive, super-exponentially
   convergent series.

The finite formulas have been checked against direct Gram matrices for n<=3,
against complete stochastic-Lagrangian semigroup spectra for t<=8, and against
the independently constructed defect Hecke matrices (including the exact first
moment) for t=9,10,11,12.  Until the accompanying representation-theoretic lemma
is incorporated into the paper, the limiting curve should be labelled
"derived/conjectural", rather than quoted as an already published theorem.

All finite spectral weights and eigenvalues are exact Python integers/Fractions.
Decimal arithmetic enters only when square roots are taken.
"""

from __future__ import annotations

import argparse
import csv
import math
from decimal import Decimal, localcontext
from fractions import Fraction
from pathlib import Path


def _product(values) -> int:
    return math.prod(values)


def orthogonal_order(dimension: int, sign: int) -> int:
    """Return |O^sign(dimension,2)| for nondegenerate even dimension."""

    if dimension < 0 or dimension % 2 or sign not in (-1, +1):
        raise ValueError("invalid binary orthogonal-group parameters")
    half = dimension // 2
    if half == 0:
        if sign != +1:
            raise ValueError("only O^+(0,2) exists")
        return 1
    value = 2 * 2 ** (half * (half - 1)) * (2**half - sign)
    for j in range(1, half):
        value *= 2 ** (2 * j) - 1
    return value


def symplectic_order(dimension: int) -> int:
    """Return |Sp(dimension,2)| for nonnegative even dimension."""

    if dimension < 0 or dimension % 2:
        raise ValueError("invalid binary symplectic-group dimension")
    half = dimension // 2
    value = 2 ** (half * half)
    for j in range(1, half + 1):
        value *= 2 ** (2 * j) - 1
    return value


def quadratic_type_sign(t: int) -> int:
    """The orthogonal type carried by the ordinary tower."""

    if t < 1:
        raise ValueError("t must be positive")
    if t % 2:
        # (-1)^((t^2-1)/8), written by residue to avoid large exponents.
        return +1 if t % 8 in (1, 7) else -1
    if t % 4 == 0:
        return +1 if t % 8 == 0 else -1
    raise ValueError("t=2 mod 4 has symplectic, not orthogonal, type")


def ordinary_defects(t: int) -> range:
    """Valid ordinary defect dimensions r for t tensor factors."""

    if t < 1:
        raise ValueError("t must be positive")
    if t % 2:
        witt = (t - 1) // 2
        # Minus type loses the final anisotropic plane.
        count = witt + 1 if quadratic_type_sign(t) == +1 else witt
        return range(count)
    if t % 4 == 2:
        return range(t // 2)
    count = t // 2 if quadratic_type_sign(t) == +1 else t // 2 - 1
    return range(count)


def stochastic_orthogonal_order(t: int) -> int:
    """Order of the binary stochastic orthogonal group O_t(2)."""

    if t % 2:
        return orthogonal_order(t - 1, quadratic_type_sign(t))
    if t % 4 == 2:
        return 2 * symplectic_order(t - 2)
    sign = quadratic_type_sign(t)
    return 2 ** (t - 2) * orthogonal_order(t - 2, sign)


def number_of_stabilizer_states(n: int) -> int:
    """Number of projective pure n-qubit stabilizer states."""

    if n < 1:
        raise ValueError("n must be positive")
    return 2**n * _product(2**j + 1 for j in range(1, n + 1))


def moment_normalization(n: int, t: int) -> int:
    """Gross--Nezami--Walter normalization Z_{n,2,t}."""

    if n < 1 or t < 1:
        raise ValueError("n and t must be positive")
    dimension = 2**n
    return dimension * _product(dimension + 2**j for j in range(t - 1))


def ordinary_multiplicity(t: int, r: int, dimension: int) -> int:
    """Exact multiplicity of the ordinary defect-r spectral sector.

    Here ``dimension=2^n`` is the Hilbert-space dimension and
    ``s=t-2r`` is the nondegenerate quotient dimension.
    """

    if r not in ordinary_defects(t):
        raise ValueError(f"ordinary defect r={r} does not exist for t={t}")
    s = t - 2 * r

    if t % 2:
        half = (s - 1) // 2
        sign = quadratic_type_sign(t)
        if half == 0:
            # This edge occurs only for plus type.
            return dimension
        numerator = dimension
        numerator *= _product(
            dimension * dimension - 4**j for j in range(half - 1)
        )
        numerator *= dimension - sign * 2 ** (half - 1)
        numerator *= dimension + 2 ** (2 * half - 1)
        denominator = orthogonal_order(2 * half, sign)

    elif t % 4 == 2:
        half = s // 2
        numerator = dimension
        numerator *= _product(
            dimension * dimension - 4**j for j in range(half - 1)
        )
        numerator *= dimension + 2 ** (2 * half - 2)
        denominator = 2 * symplectic_order(2 * half - 2)

    else:
        half = s // 2
        sign = quadratic_type_sign(t)
        numerator = _product(
            dimension * dimension - 4**j for j in range(half - 1)
        )
        numerator *= dimension - sign * 2 ** (half - 1)
        numerator *= dimension + 2 ** (2 * half - 2)
        denominator = (
            2 ** (2 * half - 2) * orthogonal_order(2 * half - 2, sign)
        )

    quotient, remainder = divmod(numerator, denominator)
    if remainder:
        raise ArithmeticError("closed multiplicity was unexpectedly nonintegral")
    return quotient


def _power_of_two_fraction(exponent: int) -> Fraction:
    if exponent >= 0:
        return Fraction(2**exponent)
    return Fraction(1, 2 ** (-exponent))


def ordinary_eigenvalue_ratio(r: int, c: int) -> Fraction:
    """F_r(2^(3-c)), the ordinary eigenvalue divided by lambda_0."""

    if r < 0:
        raise ValueError("r must be nonnegative")
    value = Fraction(1)
    x = _power_of_two_fraction(3 - c)
    for j in range(r):
        value *= Fraction(2 ** (2 * j), 2 ** (j + 1) - 1)
        value *= x + _power_of_two_fraction(1 - j)
    return value


def ordinary_eigenvalue(n: int, t: int, r: int) -> Fraction:
    """Exact nonzero normalized-Gram eigenvalue in ordinary sector r."""

    if r not in ordinary_defects(t):
        raise ValueError(f"ordinary defect r={r} does not exist for t={t}")
    base = Fraction(
        number_of_stabilizer_states(n) * stochastic_orthogonal_order(t),
        moment_normalization(n, t),
    )
    return base * ordinary_eigenvalue_ratio(r, t - n)


def finite_spectrum(n: int, t: int) -> list[tuple[str, int, Fraction]]:
    """Return (label,multiplicity,eigenvalue) for every positive sector."""

    dimension = 2**n
    spectrum: list[tuple[str, int, Fraction]] = []
    for r in ordinary_defects(t):
        spectrum.append(
            (
                f"ordinary:{r}",
                ordinary_multiplicity(t, r, dimension),
                ordinary_eigenvalue(n, t, r),
            )
        )

    if t % 4 == 0:
        # Shortening a defect containing the all-ones vector gives the
        # ordinary tower at t-1.  Its multiplicity drops by dimension, while
        # its normalized-Gram eigenvalue is unchanged.
        for r in ordinary_defects(t - 1):
            parent = ordinary_multiplicity(t - 1, r, dimension)
            multiplicity, remainder = divmod(parent, dimension)
            if remainder:
                raise ArithmeticError("exceptional shortening was nonintegral")
            spectrum.append(
                (
                    f"exceptional:{r + 1}",
                    multiplicity,
                    ordinary_eigenvalue(n, t - 1, r),
                )
            )

    # The first moment of the normalized Gram spectrum must be exactly one:
    # sum_i m_i lambda_i = N.
    state_count = number_of_stabilizer_states(n)
    first_moment = sum(Fraction(multiplicity) * eigenvalue for _, multiplicity, eigenvalue in spectrum)
    if first_moment != state_count:
        raise ArithmeticError(
            f"spectral first-moment failure at n={n}, t={t}: "
            f"{first_moment-state_count}"
        )
    return spectrum


def finite_success(n: int, t: int, precision: int = 80) -> Decimal:
    """Exact finite optimal success, rounded only at the square roots."""

    state_count = number_of_stabilizer_states(n)
    with localcontext() as context:
        context.prec = precision
        amplitude = Decimal(0)
        for _, multiplicity, eigenvalue in finite_spectrum(n, t):
            root = context.sqrt(
                Decimal(eigenvalue.numerator) / Decimal(eigenvalue.denominator)
            )
            amplitude += Decimal(multiplicity) * root / Decimal(state_count)
        return +(amplitude * amplitude)


def _decimal_power_two(exponent: int) -> Decimal:
    if exponent >= 0:
        return Decimal(2) ** exponent
    return Decimal(1) / (Decimal(2) ** (-exponent))


def euler_products(precision: int) -> tuple[Decimal, Decimal, int]:
    """Return A=prod(1+2^-j), Q=prod(1-4^-j), and the cutoff used."""

    cutoff = max(80, 4 * precision)
    with localcontext() as context:
        context.prec = precision + 12
        a_product = Decimal(1)
        q_product = Decimal(1)
        for j in range(1, cutoff + 1):
            a_product *= Decimal(1) + _decimal_power_two(-j)
            q_product *= Decimal(1) - _decimal_power_two(-2 * j)
        return +a_product, +q_product, cutoff


def limiting_base_eigenvalue(c: int, q_product: Decimal) -> Decimal:
    """Closed fixed-offset limit of the defect-zero Gram eigenvalue."""

    # A cancels from A/prod_{j=2-c}^infinity(1+2^-j), leaving a finite
    # product.  C_2=2Q exactly.
    finite_ratio = Decimal(1)
    if c <= 1:
        for j in range(1, 2 - c):
            finite_ratio *= Decimal(1) + _decimal_power_two(-j)
    else:
        for j in range(2 - c, 1):
            finite_ratio /= Decimal(1) + _decimal_power_two(-j)
    exponent = ((c - 1) * (c - 2)) // 2 + 1
    return _decimal_power_two(exponent) * q_product * finite_ratio


def limiting_spectrum(
    c: int,
    precision: int = 80,
    r_max: int = 80,
) -> tuple[list[tuple[int, Decimal, Decimal]], Decimal, Decimal]:
    """Return (r,w_r,lambda_r), total weight, and first moment."""

    if r_max < 0:
        raise ValueError("r_max must be nonnegative")
    with localcontext() as context:
        context.prec = precision
        a_product, q_product, _ = euler_products(precision)
        base = limiting_base_eigenvalue(c, q_product)
        x = _decimal_power_two(3 - c)
        eigenvalue = base
        rows: list[tuple[int, Decimal, Decimal]] = []
        for r in range(r_max + 1):
            u = 2 * r - c
            exponent = (u * u + 3 * u + 4) // 2
            weight = _decimal_power_two(-exponent)
            weight *= Decimal(1) + _decimal_power_two(-u - 2)
            weight /= a_product * q_product
            rows.append((r, +weight, +eigenvalue))
            ratio = _decimal_power_two(2 * r)
            ratio *= x + _decimal_power_two(1 - r)
            ratio /= Decimal(2 ** (r + 1) - 1)
            eigenvalue *= ratio

        mass = sum((weight for _, weight, _ in rows), Decimal(0))
        first_moment = sum(
            (weight * eigenvalue for _, weight, eigenvalue in rows), Decimal(0)
        )
        return rows, +mass, +first_moment


def limiting_success(c: int, precision: int = 80, r_max: int = 80) -> Decimal:
    """Evaluate the fixed-offset series (positive and super-exponential)."""

    with localcontext() as context:
        context.prec = precision
        rows, _, first_moment = limiting_spectrum(c, precision, r_max)
        tolerance = Decimal(10) ** (-(precision - 8))
        if abs(first_moment - Decimal(1)) > tolerance:
            raise ArithmeticError(
                f"r_max={r_max} is too small at c={c}; first moment={first_moment}"
            )
        amplitude = sum(
            (weight * context.sqrt(eigenvalue) for _, weight, eigenvalue in rows),
            Decimal(0),
        )
        return +(amplitude * amplitude)


def limiting_success_adaptive(
    c: int,
    precision: int = 50,
    max_terms: int = 200,
) -> tuple[Decimal, int]:
    """Evaluate the limit with a certified positive-series tail bound.

    Returns ``(success, terms_used)``.  Near the transition, ordinary
    double-precision accuracy requires only about five to nine terms.
    """

    with localcontext() as context:
        context.prec = precision + 10
        a_product, q_product, _ = euler_products(precision + 10)
        eigenvalue = limiting_base_eigenvalue(c, q_product)
        x = _decimal_power_two(3 - c)
        amplitude = Decimal(0)
        amplitude_tolerance = Decimal(10) ** (-(precision - 5))
        sqrt_three = context.sqrt(Decimal(3))

        for r in range(max_terms):
            u = 2 * r - c
            exponent = (u * u + 3 * u + 4) // 2
            weight = _decimal_power_two(-exponent)
            weight *= Decimal(1) + _decimal_power_two(-u - 2)
            weight /= a_product * q_product
            amplitude += weight * context.sqrt(eigenvalue)

            eigenvalue_ratio = _decimal_power_two(2 * r)
            eigenvalue_ratio *= x + _decimal_power_two(1 - r)
            eigenvalue_ratio /= Decimal(2 ** (r + 1) - 1)
            next_eigenvalue = eigenvalue * eigenvalue_ratio

            next_r = r + 1
            next_u = 2 * next_r - c
            next_exponent = (next_u * next_u + 3 * next_u + 4) // 2
            next_weight = _decimal_power_two(-next_exponent)
            next_weight *= Decimal(1) + _decimal_power_two(-next_u - 2)
            next_weight /= a_product * q_product
            next_term = next_weight * context.sqrt(next_eigenvalue)

            if next_r >= max(0, c - 3):
                q_bound = sqrt_three * _decimal_power_two(
                    (-7 * next_r + 3 * c - 7) // 2
                )
                # The exponent can be half-integral.  Supply the missing
                # sqrt(2) when its numerator is odd.
                numerator = -7 * next_r + 3 * c - 7
                if numerator % 2:
                    q_bound = sqrt_three * context.sqrt(
                        _decimal_power_two(numerator)
                    )
                if q_bound < 1 and next_term / (1 - q_bound) < amplitude_tolerance:
                    return +(amplitude * amplitude), next_r

            eigenvalue = next_eigenvalue

    raise ArithmeticError("adaptive series did not meet tolerance")


def collision_lower_limit(c: int, precision: int = 80) -> Decimal:
    """Rigorous limiting collision lower bound prod_{j=c-1}^inf(1+2^-j)^-1."""

    cutoff = max(80, 4 * precision)
    with localcontext() as context:
        context.prec = precision
        denominator = Decimal(1)
        for j in range(c - 1, cutoff + 1):
            denominator *= Decimal(1) + _decimal_power_two(-j)
        return +(Decimal(1) / denominator)


def self_check(precision: int = 60) -> None:
    """Run exact moment checks and selected independent success benchmarks."""

    # Calling finite_spectrum triggers an exact first-moment identity.
    for t in range(1, 13):
        for n in {max(1, t - 3), t, t + 2}:
            finite_spectrum(n, t)

    benchmarks = {
        (4, 4): Decimal("0.103566149246961258"),
        (5, 5): Decimal("0.145614623794954700"),
        (6, 6): Decimal("0.175714584207472454"),
        (7, 7): Decimal("0.191044155396708364"),
        (8, 8): Decimal("0.190270614977750"),
        (7, 8): Decimal("0.463205871296399"),
        (9, 8): Decimal("0.044124583926936"),
    }
    threshold = Decimal("2e-15")
    for (n, t), expected in benchmarks.items():
        observed = finite_success(n, t, precision)
        if abs(observed - expected) > threshold:
            raise AssertionError((n, t, observed, expected))

    for c in range(-8, 13):
        limiting_success(c, precision, 80)


def write_curve(
    output: Path,
    c_min: int,
    c_max: int,
    finite_t: list[int],
    precision: int,
    r_max: int,
) -> None:
    output.parent.mkdir(parents=True, exist_ok=True)
    fieldnames = [
        "p",
        "offset_c",
        "collision_lower_limit",
        "stabilizer_limit_derived",
    ]
    fieldnames += [f"finite_t{t}" for t in finite_t]
    with output.open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        for c in range(c_min, c_max + 1):
            row: dict[str, object] = {
                "p": 2,
                "offset_c": c,
                "collision_lower_limit": format(
                    collision_lower_limit(c, precision), ".30g"
                ),
                "stabilizer_limit_derived": format(
                    limiting_success(c, precision, r_max), ".30g"
                ),
            }
            for t in finite_t:
                n = t - c
                row[f"finite_t{t}"] = (
                    format(finite_success(n, t, precision), ".30g") if n >= 1 else ""
                )
            writer.writerow(row)
            print(
                f"c={c:+3d}  P_limit={row['stabilizer_limit_derived']}  "
                f"L={row['collision_lower_limit']}"
            )


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--c-min", type=int, default=-8)
    parser.add_argument("--c-max", type=int, default=12)
    parser.add_argument("--finite-t", type=int, nargs="+", default=[8, 12, 20, 40])
    parser.add_argument("--precision", type=int, default=80)
    parser.add_argument("--r-max", type=int, default=80)
    parser.add_argument(
        "--output", type=Path, default=Path("fixed_offset_curve_p2.csv")
    )
    parser.add_argument("--skip-self-check", action="store_true")
    args = parser.parse_args()

    if not args.skip_self_check:
        self_check(min(args.precision, 60))
        print("all exact-moment and benchmark checks passed")
    write_curve(
        args.output,
        args.c_min,
        args.c_max,
        args.finite_t,
        args.precision,
        args.r_max,
    )


if __name__ == "__main__":
    main()
