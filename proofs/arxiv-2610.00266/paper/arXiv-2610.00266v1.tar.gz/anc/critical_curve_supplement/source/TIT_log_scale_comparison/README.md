# Log-scale comparison of finite-n and fixed-offset curves

This supplement compares two logarithmic displays for the same nine values
`n = 4, 8, 12, 16, 24, 32, 64, 128, 256` and all integer offsets `c = -3, ..., 7`.
The previous 3-by-3 Monte Carlo figure remains unchanged.

- Panel (a): logarithmic success-probability axis. The lower-probability tail is
  expanded, but the large-n curves still overlap.
- Panel (b): logarithmic absolute finite-size deviation,
  `abs(P(n,n+c) - P_infinity(c))`. This directly resolves the magnitude of
  convergence. Absolute values omit the sign; signed differences are included
  in `data/log_comparison.csv`. Lines connect discrete integer offsets only.

These are deterministic formula comparisons, not Monte Carlo observations.
The limiting reference is the proposed fixed-offset series supplied with the
research implementation; the plot itself does not prove that series is the limit.
Sampling residuals in the previous figure are a different quantity:
`p_hat - P(n,n+c)`.

At `c=0`, the absolute finite-size deviations are approximately `3.64e-6`
for `n=32`, `5.55e-11` for `n=64`, and `7.01e-40` for `n=256`.
For 1,000 independent Bernoulli trials, the standard error near the limiting
probability at this offset is approximately `0.012`. Those Monte Carlo trials
therefore cannot resolve the small finite-size deviations for large n.

## Numerical precision

For n below 256, the inputs are the prior 90-digit formula evaluations copied
into `data/source_theory_curves.csv`. For n=256, both formulas are evaluated
again at 160-digit precision. Subtraction is performed in decimal arithmetic
before converting differences to floating point for plotting.

The especially small differences at n=256 and c=-2, 2, 6 were rechecked at
200-digit precision with a longer limiting-series truncation. Relative changes
in these differences are below `4e-81`; see `data/precision_checks.json`.
The previously exported 70-digit independent-matrix probabilities do not have
enough saved digits for these differences, which are of order `1e-79` to `1e-78`.
They are deliberately not used to generate this logarithmic comparison.

## Files and reproduction

`TIT_log_scale_comparison.pdf` is a one-page vector PDF, 7.16 by 4.55 inches,
with embedded fonts and type no smaller than 9 points. The PNG is a preview.
`compare_scales.py` generates both using `reference_evaluator.py` and the data
in this folder. Run with Python, Matplotlib, and NumPy available:

```sh
python compare_scales.py
```

The script reuses `data/log_comparison.csv` when present. To recalculate, make a
fresh copy of this folder without that generated CSV and run the script there.
