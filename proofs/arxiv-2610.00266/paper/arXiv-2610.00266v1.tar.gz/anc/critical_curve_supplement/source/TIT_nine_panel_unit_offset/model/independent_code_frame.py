#!/usr/bin/env python3
"""Independent full-ensemble PGM from affine-support and binary-code orbits.

This module contains no finite-spectrum formula, target multiplicity, or
limiting-curve expression.  It builds an exact symmetry restriction of the
stabilizer frame from affine supports, counts binary codes, and diagonalizes
that small matrix with arbitrary precision.
"""
from __future__ import annotations
import argparse
import json
import math
import time
from fractions import Fraction
from functools import lru_cache
from pathlib import Path
import mpmath as mp


def pow2(e):
    return Fraction(2**e) if e >= 0 else Fraction(1, 2**(-e))


@lru_cache(None)
def gaussian_binomial(n, r):
    if r < 0 or n < 0 or r > n:
        return 0
    r = min(r, n-r)
    numerator = math.prod(2**(n-j)-1 for j in range(r))
    denominator = math.prod(2**(r-j)-1 for j in range(r))
    value, remainder = divmod(numerator, denominator)
    assert remainder == 0
    return value


@lru_cache(None)
def injection_count(n, r):
    return math.prod(2**n-2**j for j in range(r)) if r <= n else 0


@lru_cache(None)
def gl_order(r):
    return injection_count(r, r)


def gaussian_real(k):
    """Exact real part of (1+i)^k, using integer Gaussian arithmetic."""
    a, b = 1, 0
    for _ in range(k):
        a, b = a-b, a+b
    return a


def code_counts(k):
    """Count all doubly-even binary length-k codes, grouped by rank and 1."""
    assert k >= 1
    result = {(0, 0): 1}
    singular_radical = k % 4 == 0
    for r in range(k):
        current = result.get((r, 0), 0)
        if not current:
            break
        orthogonal_singular = pow2(k-r-2) + Fraction(gaussian_real(k), 2)
        extension_vectors = orthogonal_singular - 2**r
        extensions = extension_vectors / 2**r
        if singular_radical:
            one_count = Fraction(current, 2**r)
            assert one_count.denominator == 1
            if one_count:
                result[(r+1, 1)] = int(one_count)
            extensions -= 1  # The unique extension C + <1>.
        next_count = current * extensions / (2**(r+1)-1)
        assert next_count.denominator == 1 and next_count >= 0
        if next_count:
            result[(r+1, 0)] = int(next_count)
    return dict(sorted(result.items()))


def enumerate_code_counts(k):
    """Literal enumeration for checking the code-count recurrence at small k."""
    singular = [v for v in range(2**k) if v.bit_count() % 4 == 0]
    levels = {frozenset([0])}
    result = {}
    r = 0
    while levels:
        for code in levels:
            key = (r, int((2**k-1) in code))
            result[key] = result.get(key, 0) + 1
        next_level = set()
        for code in levels:
            for v in singular:
                if v in code or any((v & c).bit_count() % 2 for c in code):
                    continue
                next_level.add(code | frozenset(v ^ c for c in code))
        levels = next_level
        r += 1
    return dict(sorted(result.items()))


def support_weight(n, k, affine_dimension):
    """Frame entry after the diagonal-character selection rule is satisfied."""
    if affine_dimension < 0 or affine_dimension > n:
        return Fraction(0)
    return sum((gaussian_binomial(n-affine_dimension, m-affine_dimension)
                * pow2(m*(m+3)//2-m*k)
                for m in range(affine_dimension, n+1)), Fraction(0))


def subdirect_counts(r, s, h, both_contain_one):
    """Subdirect row spaces of C+D, and those containing (1,1)."""
    gl = gl_order(h)
    total = gaussian_binomial(r, h) * gaussian_binomial(s, h) * gl
    containing = 0
    if both_contain_one:
        if h == 0:
            containing = 1
        else:
            zero_left, zero_right = gaussian_binomial(r-1, h), gaussian_binomial(s-1, h)
            nonzero_left = gaussian_binomial(r, h)-zero_left
            nonzero_right = gaussian_binomial(s, h)-zero_right
            containing = zero_left * zero_right * gl
            quotient, remainder = divmod(nonzero_left * nonzero_right * gl, 2**h-1)
            assert remainder == 0
            containing += quotient
    assert 0 <= containing <= total
    return total, containing


def as_mp(value):
    if isinstance(value, Fraction):
        return mp.mpf(value.numerator)/value.denominator
    return mp.mpf(value)


@lru_cache(maxsize=4)
def exact_frame_data(n, k):
    """Return exact entry numerators and the diagonal normalization factors."""
    counts = {key: value for key, value in code_counts(k).items() if key[0] <= n}
    classes = list(counts)
    # Every support weight is dyadic. A shared denominator keeps the inner
    # matrix loop entirely in integer arithmetic and avoids repeated GCDs.
    exponents = [m*(m+3)//2-m*k for m in range(n+1)]
    denominator_exponent = max(0, -min(exponents))
    common_denominator = 1 << denominator_exponent
    weights = [sum(gaussian_binomial(n-a,m-a)
                   << (exponents[m]+denominator_exponent)
                   for m in range(a,n+1)) for a in range(n+1)]
    injections = [injection_count(n, r) for r in range(n+1)]
    entries = [[Fraction(0) for _ in classes] for _ in classes]
    for i, (r, u) in enumerate(classes):
        for j in range(i+1):
            s, v = classes[j]
            value = 0
            for h in range(min(r, s)+1):
                t = r+s-h
                if t > n:
                    continue
                total, containing = subdirect_counts(r, s, h, bool(u and v))
                value += injections[t] * ((total-containing)*weights[t]
                                          + (containing*weights[t-1] if containing else 0))
            entries[i][j] = entries[j][i] = Fraction(value, common_denominator)
    scales_squared = [Fraction(counts[key], injections[key[0]]) for key in classes]
    return classes, counts, entries, scales_squared


def pgm_success(n, k, dps=80, return_matrix=False):
    started = time.perf_counter()
    classes, counts, entries, scales_squared = exact_frame_data(n, k)
    with mp.workdps(dps):
        scales = [mp.sqrt(as_mp(x)) for x in scales_squared]
        matrix = mp.matrix([[as_mp(value)*scales[i]*scales[j]
                             for j, value in enumerate(row)] for i, row in enumerate(entries)])
        values, vectors = mp.eigsy(matrix)
        # The seed belongs to the support of the positive frame by definition.
        # Tiny signed eigenvalues may only occur from finite precision.
        cutoff = max(abs(v) for v in values) * mp.power(10, -dps+15)
        retained = [i for i, value in enumerate(values) if value > cutoff]
        negative = [value for value in values if value < -cutoff]
        if negative:
            raise ArithmeticError('Insufficient precision or indefinite frame: '+str(negative[0]))
        seed_projection = sum(vectors[0, i]**2 for i in retained)
        inverse_seed = sum(vectors[0, i]**2/mp.sqrt(values[i]) for i in retained)
        success = inverse_seed**2
        residual = max(abs(x) for x in (matrix*vectors-vectors*mp.diag(values)))
        record = {'n':n, 'copies_k':k, 'offset_c':k-n,
                  'matrix_dimension':len(classes), 'code_classes':[[r,u,counts[r,u]] for r,u in classes],
                  'dps':dps, 'success':mp.nstr(success, min(dps-15, 70)),
                  'seed_projection_error':mp.nstr(abs(seed_projection-1), 8),
                  'eigen_residual_relative':mp.nstr(residual/max(abs(x) for x in matrix), 8),
                  'minimum_positive_eigenvalue':mp.nstr(min(values[i] for i in retained), 12),
                  'maximum_eigenvalue':mp.nstr(max(values), 12),
                  'numerical_rank':len(retained), 'elapsed_seconds':time.perf_counter()-started}
        if abs(seed_projection-1) > mp.power(10, -min(dps//3, 20)):
            raise ArithmeticError('Seed projection failed; raise precision')
        if return_matrix:
            return record, matrix.copy()
        return record


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--n', type=int, nargs='+', default=[4, 6, 8, 10, 16, 24, 32])
    parser.add_argument('--offsets', type=int, nargs='+', default=[0])
    parser.add_argument('--dps', type=int, default=100)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--verify-counts', action='store_true')
    args = parser.parse_args()
    if args.verify_counts:
        for k in range(1, 9):
            assert code_counts(k) == enumerate_code_counts(k), (k, code_counts(k), enumerate_code_counts(k))
            print('code enumeration passed k='+str(k), flush=True)
    rows = []
    for n in args.n:
        for c in args.offsets:
            if n+c < 1:
                continue
            rec = pgm_success(n, n+c, args.dps)
            rows.append(rec)
            args.output.write_text(json.dumps(rows, indent=2)+'\n')
            print(json.dumps(rec), flush=True)


if __name__ == '__main__':
    main()
