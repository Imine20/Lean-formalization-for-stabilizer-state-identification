#!/usr/bin/env python3
"""Simulate success/failure observations using independent frame probabilities.

The target spectrum is a comparator, never the Monte Carlo probability source.
All seeds are fixed before viewing the observations; no sample is discarded.
"""
from pathlib import Path
from decimal import Decimal, localcontext
import argparse
import csv
import json
import math
import sys
import numpy as np
from scipy.stats import beta

ROOT = Path(__file__).resolve().parent
NS = [4,8,12,16,24,32,64,128,256]
OFFSETS = list(range(-3,8))
M = 1000
SEED = 20260920


def clopper_pearson(successes, trials):
    lower = 0.0 if successes == 0 else float(beta.ppf(.025, successes, trials-successes+1))
    upper = 1.0 if successes == trials else float(beta.ppf(.975, successes+1, trials-successes))
    return lower, upper


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--allow-partial',action='store_true',help='For layout previews only.')
    args=parser.parse_args()
    indexed={}
    for name in ['prior_independent_results.json','additional_n12_n24.json','additional_n256.json','additional_unit_offsets.json','additional_n256_exceptional.json']:
        p=ROOT/'data'/name
        if not p.exists():
            continue
        for record in json.loads(p.read_text()):
            indexed[record['n'],record['offset_c']]=record
    wanted=[(n,c) for n in NS for c in OFFSETS]
    missing=[key for key in wanted if key not in indexed]
    if missing and not args.allow_partial:
        raise RuntimeError('Independent matrix computations missing: '+str(missing))
    # Monte Carlo has only this path to its probability source.
    samples=[];raw={};selected=[]
    for n,c in wanted:
        if (n,c) not in indexed:
            continue
        r=indexed[n,c];k=n+c
        p=float(Decimal(r['success']))
        assert 0<=p<=1
        rng=np.random.default_rng(np.random.SeedSequence([SEED,n,k]))
        outcomes=(rng.random(M)<p).astype(np.uint8)
        s=int(outcomes.sum());lo,hi=clopper_pearson(s,M)
        assert 0<=lo<=s/M<=hi<=1
        raw[f'n{n}_k{k}']=outcomes
        samples.append({'n':n,'copies_k':k,'offset_c':c,'trials':M,
                        'success_count':s,'mc_success':s/M,
                        'ci95_lower':lo,'ci95_upper':hi,
                        'independent_probability':r['success'],
                        'matrix_dimension':r['matrix_dimension'],'working_dps':r['dps'],
                        'seed_components':f'{SEED};{n};{k}'})
        selected.append(r)
    # Evaluate comparison curves only after all random outcomes are generated.
    sys.path.insert(0,str(ROOT/'model'))
    import reference_evaluator as reference
    curves=[]
    limits={c:str(reference.limiting_success(c,precision=90,r_max=100)) for c in range(-3,8)}
    for n in NS:
        for c in range(-3,8):
            curves.append({'n':n,'offset_c':c,'copies_k':n+c,
                           'finite_formula':str(reference.finite_success(n,n+c,precision=90)),
                           'fixed_offset_series':limits[c]})
    theory={(r['n'],r['offset_c']):r for r in curves}
    stats=[]
    for row in samples:
        t=theory[row['n'],row['offset_c']]
        with localcontext() as ctx:
            ctx.prec=100
            diff=abs(Decimal(row['independent_probability'])-Decimal(t['finite_formula']))
        assert diff<Decimal('1e-60'),row
        row['finite_formula']=t['finite_formula']
        row['fixed_offset_series']=t['fixed_offset_series']
        row['matrix_formula_difference']=str(diff)
        row['deviation_percentage_points']=100*(row['mc_success']-float(t['finite_formula']))
        row['deviation_ci95_lower_pp']=100*(row['ci95_lower']-float(t['finite_formula']))
        row['deviation_ci95_upper_pp']=100*(row['ci95_upper']-float(t['finite_formula']))
        row['ci_contains_independent_probability']=bool(row['ci95_lower']<=float(row['independent_probability'])<=row['ci95_upper'])
    for n in NS:
        rs=[r for r in samples if r['n']==n]
        stats.append({'n':n,'points':len(rs),'trials_per_point':M,'total_trials':len(rs)*M,
                      'copies_k':[r['copies_k'] for r in rs],
                      'maximum_abs_deviation_pp':max(abs(r['deviation_percentage_points']) for r in rs),
                      'rmse':math.sqrt(sum((r['mc_success']-float(r['independent_probability']))**2 for r in rs)/len(rs)),
                      'intervals_covering_probability':sum(r['ci_contains_independent_probability'] for r in rs)})
    for filename,rows in [('monte_carlo_samples.csv',samples),('theory_curves.csv',curves)]:
        with (ROOT/'data'/filename).open('w',newline='') as f:
            w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
    previous=np.load(ROOT/'data/previous_simulated_trials.npz')
    assert all(key in raw and np.array_equal(previous[key],raw[key]) for key in previous.files), 'Existing trial outcomes changed'
    np.savez_compressed(ROOT/'data/simulated_trials.npz',**raw)
    (ROOT/'data/panel_statistics.json').write_text(json.dumps(stats,indent=2)+'\n')
    (ROOT/'data/selected_independent_results.json').write_text(json.dumps(selected,indent=2)+'\n')
    summary={'n_values':NS,'sample_offsets':OFFSETS,'trials_per_point':M,
             'points':len(samples),'total_trials':len(samples)*M,'missing_points':missing,
             'previous_points_preserved':len(previous.files),'offset_step':1,
             'residual_definition':'100*(Monte Carlo frequency - finite-n probability), in percentage points',
             'interval_method':'Two-sided equal-tailed 95% Clopper-Pearson, pointwise',
             'base_seed':SEED,'rng':'NumPy default_rng / PCG64; SeedSequence([base_seed,n,k])',
             'numpy_version':np.__version__,
             'probability_source':'Independent full-ensemble PGM frame calculation',
             'outcome':'Binary success/failure, the exact success marginal of the ideal collective PGM',
             'selection_policy':'First and only run of each fixed seed; no samples rejected',
             'maximum_formula_difference':str(max(Decimal(r['matrix_formula_difference']) for r in samples))}
    (ROOT/'data/sampling_summary.json').write_text(json.dumps(summary,indent=2)+'\n')
    print(json.dumps(summary,indent=2))


if __name__=='__main__':main()
