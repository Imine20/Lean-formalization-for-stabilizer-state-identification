#!/usr/bin/env python3
"""Recompute the independent n=256, c=0 and c=4 records.

Run with Python and mpmath installed. This uses two worker processes, the
unmodified independent frame model, and exact rational matrix construction.
The subsequent eigendecomposition uses 80 guard digits above log10(trace).
No reference curve or target-spectrum implementation is imported.
"""
from concurrent.futures import ProcessPoolExecutor, as_completed
from fractions import Fraction
from pathlib import Path
import json
import sys
import time

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'model'))
import independent_code_frame as frame
import mpmath as mp

OUT = ROOT / 'data/additional_n256_exceptional.json'


def calculate(k):
    start = time.perf_counter()
    print(f'k={k}: constructing exact independent frame', flush=True)
    classes, _, entries, scales2 = frame.exact_frame_data(256, k)
    trace = sum((entries[i][i]*scales2[i] for i in range(len(classes))), Fraction(0))
    with mp.workdps(80):
        dps = max(80, int(mp.ceil(mp.log10(frame.as_mp(trace)))) + 80)
    print(f'k={k}: exact matrix built, dimension={len(classes)}, dps={dps}, seconds={time.perf_counter()-start:.2f}', flush=True)
    rec = frame.pgm_success(256, k, dps)
    rec['total_elapsed_seconds_including_exact_build'] = time.perf_counter()-start
    print(f'k={k}: finished, success={rec["success"]}, seconds={time.perf_counter()-start:.2f}', flush=True)
    return rec


if __name__ == '__main__':
    OUT.parent.mkdir(parents=True, exist_ok=True)
    rows = []
    with ProcessPoolExecutor(max_workers=2) as pool:
        futures = [pool.submit(calculate, k) for k in (256, 260)]
        for future in as_completed(futures):
            rows.append(future.result())
            rows.sort(key=lambda r: r['copies_k'])
            OUT.write_text(json.dumps(rows, indent=2)+'\n')
            print('checkpoint: '+str(OUT), flush=True)
