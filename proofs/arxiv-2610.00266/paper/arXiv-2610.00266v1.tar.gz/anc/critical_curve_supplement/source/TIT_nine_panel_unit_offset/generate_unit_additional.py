#!/usr/bin/env python3
"""Compute missing unit-offset probabilities using the independent frame only."""
from pathlib import Path
import json
import math
import sys

BASE = Path(__file__).resolve().parent
sys.path.insert(0, str(BASE / 'model'))
from independent_code_frame import exact_frame_data, pgm_success

OUTPUT = BASE / 'data' / 'additional_unit_offsets.json'


def choose_precision(n, k):
    classes, counts, entries, scales = exact_frame_data(n, k)
    trace = sum(entries[i][i] * scales[i] for i in range(len(classes)))
    log_trace = math.log10(trace.numerator) - math.log10(trace.denominator)
    return max(100, math.ceil(log_trace) + 80)


def main():
    rows = json.loads(OUTPUT.read_text()) if OUTPUT.exists() else []
    completed = {(r['n'], r['offset_c']) for r in rows}
    for n, offsets in [(12, [-2, 0, 2, 4, 6]),
                       (24, [-2, 0, 2, 4, 6]),
                       (256, [-2, 2, 6])]:
        for c in offsets:
            if (n, c) in completed:
                continue
            k = n + c
            print(f'Start n={n}, c={c}', flush=True)
            dps = choose_precision(n, k)
            print(f'Precision={dps}', flush=True)
            row = pgm_success(n, k, dps=dps)
            rows.append(row)
            OUTPUT.write_text(json.dumps(rows, indent=2) + '\n')
            print(f'Completed n={n}, c={c}, P={row["success"]}, seconds={row["elapsed_seconds"]:.3f}', flush=True)


if __name__ == '__main__':
    main()
