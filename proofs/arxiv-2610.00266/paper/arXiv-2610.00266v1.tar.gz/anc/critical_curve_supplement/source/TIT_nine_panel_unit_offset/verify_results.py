#!/usr/bin/env python3
"""Verify the final integer-offset data and preservation of the previous run."""
from pathlib import Path
import argparse
import csv
import hashlib
import json
import math
import numpy as np
from scipy.stats import binomtest

ROOT=Path(__file__).resolve().parent


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--check-original-files',action='store_true',
                        help='Also check historical absolute paths; requires the original workstation.')
    args=parser.parse_args()
    rows=list(csv.DictReader((ROOT/'data/monte_carlo_samples.csv').open()))
    ns=[4,8,12,16,24,32,64,128,256]
    expected={(n,c) for n in ns for c in range(-3,8)}
    keys={(int(r['n']),int(r['offset_c'])) for r in rows}
    assert keys==expected and len(rows)==99
    raw=np.load(ROOT/'data/simulated_trials.npz')
    old=np.load(ROOT/'data/previous_simulated_trials.npz')
    assert len(raw.files)==99 and len(old.files)==54
    assert all(np.array_equal(old[k],raw[k]) for k in old.files)
    max_ci_error=0.0;max_residual_error=0.0
    for r in rows:
        n,k=int(r['n']),int(r['copies_k']);M=int(r['trials']);s=int(r['success_count'])
        assert M==1000 and k==n+int(r['offset_c'])
        key=f'n{n}_k{k}'
        assert len(raw[key])==M and int(raw[key].sum())==s
        rng=np.random.default_rng(np.random.SeedSequence([20260920,n,k]))
        expected_raw=(rng.random(M)<float(r['independent_probability'])).astype(np.uint8)
        assert np.array_equal(raw[key],expected_raw)
        exact=binomtest(s,M).proportion_ci(.95,method='exact')
        max_ci_error=max(max_ci_error,abs(exact.low-float(r['ci95_lower'])),abs(exact.high-float(r['ci95_upper'])))
        p=float(r['finite_formula'])
        comparisons=[(100*(s/M-p),float(r['deviation_percentage_points'])),
                     (100*(exact.low-p),float(r['deviation_ci95_lower_pp'])),
                     (100*(exact.high-p),float(r['deviation_ci95_upper_pp']))]
        max_residual_error=max(max_residual_error,*(abs(a-b) for a,b in comparisons))
    assert max_ci_error<1e-10 and max_residual_error<1e-8
    stats=json.loads((ROOT/'data/panel_statistics.json').read_text())
    for stat in stats:
        rs=[r for r in rows if int(r['n'])==stat['n']]
        assert len(rs)==11
        rmse=math.sqrt(sum((float(r['mc_success'])-float(r['independent_probability']))**2 for r in rs)/11)
        assert abs(rmse-stat['rmse'])<1e-14
    plot=json.loads((ROOT/'figure_manifest.json').read_text())
    assert plot['sample_points']==99 and not plot['missing_points']
    assert plot['csv_sha256']==hashlib.sha256((ROOT/'data/monte_carlo_samples.csv').read_bytes()).hexdigest()
    assert all(p['sample_offsets']==list(range(-3,8)) for p in plot['panels'])
    low,high=plot['common_residual_ylim']
    assert all(float(r['deviation_ci95_lower_pp'])>=low and float(r['deviation_ci95_upper_pp'])<=high for r in rows)
    original=json.loads((ROOT/'previous_version_manifest.json').read_text())
    if args.check_original_files:
        for r in original:
            p=Path(r['path'])
            assert hashlib.sha256(p.read_bytes()).hexdigest()==r['sha256']
            assert p.stat().st_mtime_ns==r['mtime_ns']
    result={'status':'pass','n_values':ns,'offsets':list(range(-3,8)),
            'points':99,'trials':99000,'old_points_preserved_bitwise':54,
            'new_points':45,'max_independent_ci_error':max_ci_error,
            'max_residual_ci_error_pp':max_residual_error,
            'all_nine_rmse_recomputed':True,
            'previous_files_unchanged':len(original) if args.check_original_files else None,
            'historical_original_files_checked':args.check_original_files,
            'all_residual_intervals_within_common_axis_range':True}
    (ROOT/'validation_checks.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))


if __name__=='__main__':main()
