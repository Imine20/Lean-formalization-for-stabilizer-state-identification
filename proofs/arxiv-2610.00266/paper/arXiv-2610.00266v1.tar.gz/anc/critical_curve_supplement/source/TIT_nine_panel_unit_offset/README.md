# Unit-offset Monte Carlo figure with signed deviations

最终图：`TIT_unit_offset_with_deviations.pdf`。单页 3×3 复合面板，每个 n 的面板上方显示成功概率，下方显示独立的有符号偏差。九个 n 仍为 4,8,12,16,24,32,64,128,256。

## 本次修改

- 所有 n 均采样 c=-3,-2,...,7，间隔为 1，共 99 个点。
- 每点仍为 1,000 次试验，总计 99,000 次。旧版 54 个点的全部原始 0/1 试验逐位保留，仅新增 45 个点。
- 下方偏差定义为 Δ=100(模拟成功频率−有限 n 理论成功概率)，单位为**百分点**（pp），不是相对百分误差。
- 偏差图使用共同尺度和明确的零参考线，显示偏差方向及大小。正值表示模拟频率高于理论值，负值表示低于理论值。
- 偏差误差棒由原始 Clopper–Pearson 区间减去对应的理论概率，再乘以 100 得到。它是逐点 95% 区间，不是 99 点同时覆盖的置信带。

旧版间隔为 2，是为控制新增高精度矩阵的计算量而采用的稀疏取点，并非理论或测量模型要求。本次补齐先前未独立计算的 n=12,24,256 的偶数 offset。其余缺少的采样点使用已经保存的独立矩阵概率，不使用插值补点。

## 数据和统计含义

每个二项试验的概率来自完整均匀纯稳定子态系综的独立 PGM frame 计算。只模拟理想集体测量的成功/失败边缘分布，不模拟物理电路或完整测量输出标签。目标有限谱公式在试验生成后才被导入，用于比较和绘制理论线。

随机数为 NumPy PCG64，种子由 `SeedSequence([20260920,n,k])` 固定产生。没有为减小偏差而重选随机种子或丢弃试验。所有原始试验保存在 `data/simulated_trials.npz`。新版运行器还与 `data/previous_simulated_trials.npz` 自动逐位核对旧样本。

`data/monte_carlo_samples.csv` 保存成功数、频率、95% 区间、独立概率、目标概率和三列偏差数据。`data/panel_statistics.json` 保存每个 n 的 RMSE；PDF 将 RMSE 也统一表示为百分点。RMSE 不是置信区间或单点显著性检验。

下方区间是否跨零，只对应其所在点的理论概率与该点数据是否相容。图没有宣称 Monte Carlo 波动证明或反驳固定偏移极限；也没有把同一独立概率产生的二项试验当作第二套测量实现。

## 版式与复现

PDF 为 7.16×8.35 英寸双栏宽度，矢量曲线与文字，基准字号 9–10 pt，字体嵌入。数据来源、实际取点、偏差坐标范围和数据哈希见 `figure_manifest.json`；最终 PDF 检查见 `pdf_preflight.json`。

在本文件夹的新副本中运行：

```sh
PYTHONDONTWRITEBYTECODE=1 python prepare_samples.py
PYTHONDONTWRITEBYTECODE=1 python plot_unit_offset.py
```

需要 NumPy、SciPy、Matplotlib、mpmath。独立新增计算脚本为 `generate_unit_additional.py` 和 `generate_exceptional.py`。生成过程保留全部既有研究文件与上一版图，来源哈希及修改时间记录在 `previous_version_manifest.json`。

版式依据：[IEEE 图像尺寸](https://journals.ieeeauthorcenter.ieee.org/create-your-ieee-journal-article/create-graphics-for-your-article/resolution-and-size/) 与 [文件格式和字号](https://journals.ieeeauthorcenter.ieee.org/create-your-ieee-journal-article/create-graphics-for-your-article/file-formatting/)。区间方法：[NIST 精确二项置信限](https://itl.nist.gov/div898/software/dataplot/refman2/auxillar/exacbici.htm)。
