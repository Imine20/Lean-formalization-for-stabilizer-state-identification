#!/usr/bin/env python3
"""Nine composite panels: success curves above and signed deviations below."""
from pathlib import Path
import csv
import hashlib
import json
import math
import string
import textwrap
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.ticker import FormatStrFormatter

ROOT=Path(__file__).resolve().parent
NS=[4,8,12,16,24,32,64,128,256]
OFFSETS=list(range(-3,8))
BLUE='#145A86'
RUST='#A04428'


def read_csv(name):
    with (ROOT/'data'/name).open() as f:return list(csv.DictReader(f))


def main():
    samples=read_csv('monte_carlo_samples.csv');theory=read_csv('theory_curves.csv')
    statistics={r['n']:r for r in json.loads((ROOT/'data/panel_statistics.json').read_text())}
    summary=json.loads((ROOT/'data/sampling_summary.json').read_text())
    bound=max(max(abs(float(r['deviation_ci95_lower_pp'])),abs(float(r['deviation_ci95_upper_pp']))) for r in samples)
    residual_bound=max(4,2*math.ceil(bound/2))
    plt.rcParams.update({'font.family':'serif','font.serif':['Times New Roman','DejaVu Serif'],
        'mathtext.fontset':'stix','font.size':9,'axes.titlesize':10,'axes.labelsize':9,
        'xtick.labelsize':9,'ytick.labelsize':9,'legend.fontsize':9,
        'axes.linewidth':.65,'xtick.major.width':.6,'ytick.major.width':.6,
        'xtick.major.size':2.5,'ytick.major.size':2.5,'pdf.fonttype':42,'ps.fonttype':42,
        'svg.fonttype':'path','figure.facecolor':'white','savefig.facecolor':'white'})
    fig=plt.figure(figsize=(7.16,8.35))
    outer=fig.add_gridspec(3,3,left=.088,right=.985,bottom=.18,top=.93,wspace=.22,hspace=.34)
    legends=None;layout_records=[]
    for index,n in enumerate(NS):
        row,col=divmod(index,3)
        inner=outer[row,col].subgridspec(2,1,height_ratios=[3.1,1.4],hspace=.055)
        upper=fig.add_subplot(inner[0]);lower=fig.add_subplot(inner[1],sharex=upper)
        ts=sorted([t for t in theory if int(t['n'])==n],key=lambda t:int(t['offset_c']))
        rs=sorted([r for r in samples if int(r['n'])==n],key=lambda r:int(r['offset_c']))
        c=[int(t['offset_c']) for t in ts]
        limit=upper.plot(c,[float(t['fixed_offset_series']) for t in ts],
                         ls=(0,(4,2.2)),color='.57',lw=1,zorder=1)[0]
        finite=upper.plot(c,[float(t['finite_formula']) for t in ts],color='.1',lw=1.15,zorder=2)[0]
        x=np.array([int(r['offset_c']) for r in rs]);y=np.array([float(r['mc_success']) for r in rs])
        lo=np.array([float(r['ci95_lower']) for r in rs]);hi=np.array([float(r['ci95_upper']) for r in rs])
        monte=upper.errorbar(x,y,yerr=[y-lo,hi-y],fmt='o',ms=3.7,mfc='white',mec=BLUE,
                            mew=.8,ecolor=BLUE,elinewidth=.85,capsize=1.8,capthick=.75,zorder=4)
        upper.set_title(fr'({string.ascii_lowercase[index]})  $n={n}$',loc='left',pad=6)
        upper.text(.965,.08,fr'$k={n-3},{n-2},\ldots,{n+7}$'+'\n'+r'$M=1\,000$ per offset',
                   transform=upper.transAxes,ha='right',va='bottom',fontsize=9,linespacing=1.25,
                   bbox={'facecolor':'white','edgecolor':'none','pad':.8})
        upper.set_ylim(-.04,1.07);upper.set_yticks([0,.5,1])
        upper.yaxis.set_major_formatter(FormatStrFormatter('%.1g'))
        upper.tick_params(labelbottom=False)
        delta=np.array([float(r['deviation_percentage_points']) for r in rs])
        dlo=np.array([float(r['deviation_ci95_lower_pp']) for r in rs]);dhi=np.array([float(r['deviation_ci95_upper_pp']) for r in rs])
        lower.axhline(0,color='.2',lw=.8,zorder=1)
        lower.vlines(x,0,delta,color=RUST,lw=.7,zorder=2)
        lower.errorbar(x,delta,yerr=[delta-dlo,dhi-delta],fmt='o',color=RUST,ecolor=RUST,
                       ms=3.0,mew=.6,elinewidth=.75,capsize=1.5,capthick=.65,zorder=3)
        lower.set_ylim(-residual_bound,residual_bound);lower.set_yticks([-residual_bound,0,residual_bound])
        lower.text(.97,.94,f'RMSE {100*statistics[n]["rmse"]:.2f} pp',transform=lower.transAxes,
                   ha='right',va='top',fontsize=9,color=RUST,
                   bbox={'facecolor':'white','edgecolor':'none','pad':.8})
        for ax in [upper,lower]:
            ax.set_xlim(-3.5,7.5);ax.set_xticks(OFFSETS)
            ax.tick_params(direction='in',top=True,right=True,pad=3)
            ax.grid(axis='y',ls=':',lw=.4,color='.9',zorder=0)
            if col:ax.tick_params(labelleft=False)
        if col==0:
            upper.set_ylabel('Success probability',labelpad=6)
            lower.set_ylabel(r'$\Delta$ (pp)',labelpad=5)
        if legends is None:legends=[finite,limit,monte]
        layout_records.append({'n':n,'sample_offsets':x.tolist(),'residual_bound_pp':residual_bound})
    fig.legend(legends,['Finite-$n$ formula','Fixed-offset series','Monte Carlo (95% CI)'],
               loc='upper center',bbox_to_anchor=(.535,.995),ncol=3,frameon=False,
               handlelength=2,columnspacing=1.6,handletextpad=.6,borderpad=.1)
    fig.text(.53,.135,r'Offset $c=k-n$ (unit spacing)',ha='center',va='center',fontsize=10)
    fig.text(.088,.1,r'Lower strips: $\Delta=100(\widehat{P}-P_{n,n+c})$ in percentage points; zero denotes agreement with finite-$n$ theory.',
             fontsize=9,ha='left',va='top')
    caption=('Each point uses 1,000 Bernoulli trials from an independently computed PGM probability; '
             'bars are pointwise 95% Clopper-Pearson intervals, shifted by the finite-n probability in the lower strips. '
             'All integer offsets from -3 to 7 are sampled. Uniform pure stabilizer states; ideal collective measurement.')
    fig.text(.088,.073,'\n'.join(textwrap.wrap(caption,width=111)),ha='left',va='top',fontsize=9,linespacing=1.25)
    fig.canvas.draw();renderer=fig.canvas.get_renderer();bounds=fig.bbox
    for t in fig.findobj(matplotlib.text.Text):
        if t.get_visible() and t.get_text():
            box=t.get_window_extent(renderer)
            if box.width and box.height:
                assert box.x0>=-.5 and box.y0>=-.5 and box.x1<=bounds.width+.5 and box.y1<=bounds.height+.5,('Text outside page',t.get_text())
    filename=ROOT/'TIT_unit_offset_with_deviations.pdf'
    fig.savefig(filename,metadata={'Title':'Unit-offset stabilizer identification with signed Monte Carlo deviations',
                                  'Author':'','Creator':'Reproducible independent-frame Monte Carlo visualization'})
    fig.savefig(ROOT/'TIT_unit_offset_with_deviations.png',dpi=450)
    plt.close(fig)
    manifest={'layout':[3,3],'composite_panels':9,'axes_per_panel':2,'pdf_inches':[7.16,8.35],
              'n_values':NS,'minimum_base_font_pt':9,'offset_step':1,'residual_units':'percentage points',
              'residual_definition':'100*(Monte Carlo frequency - finite-n probability)',
              'common_residual_ylim':[-residual_bound,residual_bound],
              'sample_points':len(samples),'missing_points':summary['missing_points'],
              'panels':layout_records,'caption':caption,
              'csv_sha256':hashlib.sha256((ROOT/'data/monte_carlo_samples.csv').read_bytes()).hexdigest()}
    (ROOT/'figure_manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
    print(filename)


if __name__=='__main__':main()
